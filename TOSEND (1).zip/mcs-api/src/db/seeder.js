import { populateModule, populateModuleAccess } from '../services/module.service.js';

export const populate = async(req, res) => {
    try {
        await populateModule();
        await populateModuleAccess()
        
        console.log("SEEDER SUCCESSFULLY EXECUTED!")
    } catch (error) {
        console.log("SEEDER EXECUTION FAILED!")
    }
}


await populate()