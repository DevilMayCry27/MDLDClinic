export const authenticate = (un, pw) => {
  let q = `SELECT 
  ClinicPatientsPass.ID,
  ClinicPatients.FirstName,
  ClinicPatients.LastName,
  UserType.Name AS PositionName,
  ClinicPatientsPass.Password
  FROM ClinicPatientsPass
  INNER JOIN ClinicPatients ON ClinicPatients.EmployeeCode = ClinicPatientsPass.EmployeeCode
  INNER JOIN UserType ON UserType.ID = ClinicPatientsPass.UserLevel
  WHERE ClinicPatientsPass.Status<>2
  AND ClinicPatientsPass.UserName='${un}'
  AND ClinicPatientsPass.Password='${pw}'`;

  return q;
};

export const getUserListQuery = () => {
  let q = `SELECT 
  ClinicPatientsPass.ID,
  ClinicPatients.FirstName,
  ClinicPatients.MiddleName,
  ClinicPatients.LastName,
  Department.ID AS DepartmentId,
  Department.Name AS DepartmentName,
  UserType.Name AS UserType,
  DepartmentSection.Name AS SectionName,
  ClinicPatientsPass.UserName,
  ClinicPatientsPass.Status AS Status
  FROM ClinicPatientsPass
  INNER JOIN ClinicPatients ON ClinicPatients.EmployeeCode = ClinicPatientsPass.EmployeeCode
  INNER JOIN Department ON Department.id = ClinicPatients.DepartmentId
  INNER JOIN UserType ON UserType.ID = ClinicPatientsPass.UserLevel
  INNER JOIN DepartmentSection ON DepartmentSection.ID = ClinicPatients.DepartmentSection
  WHERE ClinicPatientsPass.Status <> 2`;

  return q;
};

export const getUserByUsernameQuery = (un) => {
  let q = `SELECT * FROM [ClinicPatientsPass] WHERE UserName = '${un}'`;

  return q;
};

export const postUserQuery = (UserName, hashPwd, Status) => {
  let q = `INSERT INTO [User] (UserName,Password,Status) VALUES ('${UserName}','${hashPwd}',${Status})`;

  return q;
};

export const putUserQuery = (Status, UserId) => {
  let q = `UPDATE [User] SET status=${Status} WHERE ID = ${UserId}`;

  return q;
};

export const deleteUserQuery = (user_id) => {
  let q = `UPDATE [User] SET Status=2 WHERE ID = ${user_id}`;

  return q;
};

export const getUserProfileQuery = (user_id) => {
  let q = `SELECT
  ClinicPatients.FirstName,
  ClinicPatients.MiddleName,
  ClinicPatients.LastName,
  ClinicPatientsPass.UserLevel,
  ClinicPatientsPass.ID as UserID
    FROM ClinicPatients
    INNER JOIN ClinicPatientsPass ON  ClinicPatientsPass.ID = ClinicPatients.ID
    WHERE ClinicPatientsPass.ID =  ${user_id}`;

  return q;
};

export const postUserProfileQuery = (
  UserId,
  FirstName,
  MiddleName,
  LastName,
  DepartmentId,
  PositionId,
  SectionId,
  Status
) => {
  let q = `INSERT INTO UserProfile (UserId, FirstName, MiddleName, LastName, DepartmentId, PositionId, SectionId, Status) VALUES (${UserId},'${FirstName}','${MiddleName}','${LastName}',${DepartmentId},${PositionId},${SectionId},${Status})`;

  return q;
};

export const putUserProfileQuery = (
  FirstName,
  MiddleName,
  LastName,
  DepartmentId,
  PositionId,
  SectionId,
  Status,
  UserId
) => {
  let q = `UPDATE UserProfile SET FirstName='${FirstName}', MiddleName='${MiddleName}', LastName='${LastName}', DepartmentId=${DepartmentId}, PositionId=${PositionId}, SectionId=${SectionId}, Status=${Status} WHERE UserId = ${UserId}`;

  return q;
};

export const deleteUserProfileQuery = (user_id) => {
  let q = `UPDATE UserProfile SET Status=2 WHERE UserId = ${user_id}`;

  return q;
};

export const getPositionListQuery = () => {
  let q = `SELECT 
    UserType.ID, 
    UserType.Name AS PositionName
    FROM UserType `;

  return q;
};

export const getPositionByNameQuery = (PositionName) => {
  let q = `SELECT UserType.ID, UserType.Name FROM UserType WHERE UserType.Name = '${PositionName}'`;

  return q;
};

export const postPositionQuery = (PositionName) => {
  let q = `INSERT INTO UserType (Name) VALUES ('${PositionName}')`;

  return q;
};

export const putPositionQuery = (PositionId, PositionName) => {
  let q = `UPDATE UserType SET Name = '${PositionName}' WHERE ID = ${PositionId}`;

  return q;
};

export const deletePositionQuery = (PositionId) => {
  let q = `UPDATE UserType SET status=2 WHERE ID = ${PositionId}`;

  return q;
};

export const getTrailLogsQuery = () => {
  let q = `SELECT 
        TrailLog.*
        FROM TrailLog
        ORDER BY TrailLog.CreatedAt DESC`;

  return q;
};

export const postTrailLogsQuery = (module, action, status, ip_address) => {
  let q = `INSERT INTO TrailLog (ModuleId, Action, Status, IpAddress) VALUES (${module}, '${action}', ${status}, '${ip_address}')`;

  return q;
};

export const getModuleListQuery = () => {
  let q = `SELECT ID, Feature FROM  WebFeature WHERE Status = 1`;

  return q;
};

export const postModuleQuery = (ID, Feature, Menu, App) => {
  let q = `IF NOT EXISTS(SELECT * FROM WebFeature WHERE ID = ${ID}) INSERT INTO WebFeature (ID,Feature,Menu,Status,IsHris,App) VALUES (${ID},'${Feature}','${Menu}',1,0,${App});`;

  return q;
};

export const getWebFeatureAccessByPositionQuery = (PositionId) => {
  let q = `SELECT 
    WebFeatureAccess.ID, 
    WebFeature.ID AS WebFeatureId, 
    WebFeature.Menu, 
    WebFeature.App,
    WebApp.AppName,
    WebFeature.Feature AS FeatureName, 
    WebFeatureAccess.Store, 
    WebFeatureAccess.Retrieve, 
    WebFeatureAccess.Modify, 
    WebFeatureAccess.Destroy, 
    WebFeatureAccess.Report 
    FROM  WebFeatureAccess 
    INNER JOIN WebFeature ON WebFeature.ID =  WebFeatureAccess.WebFeatureID 
    INNER JOIN WebApp ON WebApp.ID = WebFeature.App
    WHERE WebFeatureAccess.UserTypeID = ${PositionId} 
    AND WebFeatureAccess.Status = 1
    AND WebFeature.IsHris = 0
    AND WebApp.Status = 1
    ORDER BY WebApp.ID`;

  return q;
};

export const postWebFeatureAccessQuery = (UserTypeID, WebFeatureId) => {
  let q = `INSERT INTO WebFeatureAccess (UserTypeID,WebFeatureId) VALUES (${UserTypeID},${WebFeatureId})`;
  console.log(q);
  return q;
};

export const putWebFeatureAccessQuery = (
  Store,
  Retrieve,
  Modify,
  Destroy,
  Report,
  ID
) => {
  let q = `UPDATE WebFeatureAccess SET Store = ${Store}, Retrieve = ${Retrieve}, Modify = ${Modify}, Destroy = ${Destroy}, Report = ${Report}  WHERE ID = ${parseInt(
    ID
  )}`;

  return q;
};

export const isModuleExistQuery = (ID) => {
  let q = `SELECT * FROM WebFeature WHERE ID = ${parseInt(ID)}`;

  return q;
};

export const getMedicineListQuery = () => {
  let q = `SELECT 
    WebMedicine.*,
    DossageForm.Form AS FormName,
    Uom.Unit AS UomName,
    0 AS Stock
    FROM WebMedicine 
    LEFT JOIN DossageForm ON DossageForm.ID = WebMedicine.DossageFormID
    INNER JOIN Uom ON Uom.ID = WebMedicine.UomID
    WHERE WebMedicine.Status = 1`;

  return q;
};

export const postMedicineQuery = (
  Code,
  GenericName,
  LabelClaim,
  UomID,
  UnitPrice
) => {
  let q = `INSERT INTO WebMedicine(Code, GenericName, LabelClaim, UomID, UnitPrice) VALUES ('${Code}','${GenericName}','${LabelClaim}',${UomID},${UnitPrice})`;

  return q;
};

export const putMedicineQuery = (
  MedicineId,
  Code,
  GenericName,
  LabelClaim,
  UnitPrice,
  UomID
) => {
  let q = `UPDATE WebMedicine SET Code = '${Code}', GenericName = '${GenericName}', LabelClaim = '${LabelClaim}', UomID = ${UomID}, UnitPrice = ${UnitPrice} WHERE ID = ${MedicineId}`;

  return q;
};

export const deleteMedicineQuery = (MedicineId) => {
  let q = `UPDATE WebMedicine SET Status=2 WHERE ID = ${MedicineId}`;

  return q;
};

export const getDossageFormListQuery = () => {
  let q = `SELECT * FROM DossageForm WHERE Status = 1`;

  return q;
};

export const postDossageFormQuery = (Form) => {
  let q = `INSERT INTO DossageForm(Form) VALUES ('${Form}')`;

  return q;
};

export const putDossageFormQuery = (DossageFormId, Form) => {
  let q = `UPDATE DossageForm SET Form = '${Form}' WHERE ID = ${DossageFormId}`;

  return q;
};

export const deleteDossageFormQuery = (DossageFormId) => {
  let q = `UPDATE DossageForm SET Status=2 WHERE ID = ${DossageFormId}`;

  return q;
};

export const isWebFeatureAccessExistQuery = (utype_id, feature_id) => {
  let q = `SELECT ID FROM WebFeatureAccess WHERE WebFeatureID = '${feature_id}' AND UserTypeID = '${utype_id}'`;
  return q;
};

export const postUomQuery = (Unit) => {
  let q = `INSERT INTO Uom(Unit) VALUES ('${Unit}')`;

  return q;
};

export const putUomQuery = (UomId, Unit) => {
  let q = `UPDATE Uom SET Unit = '${Unit}' WHERE ID = ${UomId}`;

  return q;
};

export const deleteUomQuery = (UomId) => {
  let q = `UPDATE Uom SET Status=2 WHERE ID = ${UomId}`;

  return q;
};
