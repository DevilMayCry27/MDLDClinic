import sql from "mssql";
import dotenv from "dotenv";

dotenv.config();

export const config = {
  port: 1433,
  server: process.env.DB_HOST,
  user: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  options: {
    trustedConnection: true,
    enableArithPort: true,
    trustServerCertificate: true,
    encrypt: process.env.ENV == "development",
  },
  requestTimeout: 0,
};

export const executeQuery = async (q) => {
  let pool = await sql.connect(config);
  let result = await pool.request().query(q);
  return result.recordsets[0];
};

export default sql.connect(config);

export const db = async () => {
  let pool = await sql.connect(config);
  return await pool.request();
};
