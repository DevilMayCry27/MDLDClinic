import { executeQuery } from "../db/connection.js";

export const getOnlineUsers = async (userIds = []) => {
  if (userIds.length === 0) {
    return [];
  }

  let q = `SELECT u.ID,FirstName,MiddleName,LastName FROM Users as u LEFT JOIN ClinicPatients as e ON e.ID = u.EmployeeID WHERE u.ID IN (${userIds.join(
    ","
  )});`;

  return await executeQuery(q);
};
