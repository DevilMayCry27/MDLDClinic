import {
  getRelationListService,
  postRelationService,
  putRelationService,
  deleteRelationService,
} from "../services/relation.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const RelationListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Relation List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getRelationListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeRelationController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Created New Relation",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postRelationService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const destroyRelationController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Deleted a Relation with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await deleteRelationService(req.params.id);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const modifyRelationController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Updated a Relation with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    req.body.RelationId = req.params.id;
    const result = await putRelationService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
