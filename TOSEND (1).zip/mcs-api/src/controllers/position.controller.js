import {
  getPositionList,
  postPosition,
  putPosition,
  deletePosition,
} from "../services/position.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const positionList = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Position List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getPositionList();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storePosition = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Created New Position",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postPosition(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const destroyPosition = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Deleted a Position with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await deletePosition(req.params.id);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const modifyPosition = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Updated a Position with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    req.body.PositionId = req.params.id;
    const result = await putPosition(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
