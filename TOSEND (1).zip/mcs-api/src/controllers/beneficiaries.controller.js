import {
  getBeneficiariesListService,
  postBeneficiariesService,
  putBeneficiariesService,
  deleteBeneficiariesService,
} from "../services/beneficiaries.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const beneficiariesListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Beneficiaries List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getBeneficiariesListService(req.params.PID);
    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeBeneficiariesController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Created New Beneficiaries",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postBeneficiariesService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const destroyBeneficiariesController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Deleted a Beneficiaries with Id: ${req.params.ID}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    console.log(req.params);
    const result = await deleteBeneficiariesService(req.params.BID);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const modifyBeneficiariesController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Updated a Beneficiaries with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    req.body.ID = req.params.id;
    const result = await putBeneficiariesService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
