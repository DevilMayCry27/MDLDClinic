import { getCurrentUserInfoByUserId, getUserById, updatePassword } from "../services/profile.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { moduleType } from "../utils/constant.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { encryptDecrypt, isHashCodeMatch } from "./../utils/w1252.js";

export const currentUserProfile = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.general,
    action: "Created New Position",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    // get current user info from token
    const user = (await getUserById(req.user.id))[0];

    const userFullInfo = await getCurrentUserInfoByUserId(user.ID);

    return res.status(200).json(userFullInfo);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const changePass = async (req, res) => {
  // username, old, password, new password, confirm new password
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.general,
    action: "Created New Position",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    // check if username exist
    const { oldPassword, newPassword } = req.body;

    const user = (await getUserById(req.user.id))[0];

    if (!user) {
      return res.status(400).json({ message: "Invalid Credentials" });
    }

    // check if old password is same with user's password
    if (!isHashCodeMatch(user.Password, oldPassword)) {
      return res.status(400).json({ message: "Invalid Credentials: Password doesn't match" });
    }

    const hashPassword = encryptDecrypt(newPassword);

    // update password
    await updatePassword(user.ID, user.UserName, hashPassword);

    return res.status(200).json("password reset successfull");
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const updateProfile = async (req, res) => {
  // username, old, password, new password, confirm new password
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.general,
    action: "Created New Position",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const { FirstName, MiddleName, LastName, ContactNo, StreetNo, Baranggay, MunicipalityID, ProvinceID } = req.body;


    const user = (await getUserById(req.user.id))[0];

    if (!user) {
      return res.status(400).json({ message: "Unauthorize" });
    }

    const updatedUser = await updateProfileByCurrentUser(
      FirstName,
      MiddleName,
      LastName,
      ContactNo,
      StreetNo,
      Baranggay,
      MunicipalityID,
      ProvinceID,
      parseInt(user.EmployeeID)
    );

    return res.status(200).json("profile updated successfully");
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const uploadPhoto = async (req, res) => {
  // console.log(req.body.FileName);
  // console.log(req.file);

  return res.status(200).json("profile pic updated successfully");
};
