import {
  getDepartmentList,
  postDepartment,
  putDepartment,
  deleteDepartment,
} from "../services/department.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const departmentList = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Department List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getDepartmentList();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeDepartment = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Created New Department",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postDepartment(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const destroyDepartment = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Deleted a Department with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await deleteDepartment(req.params.id);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const modifyDepartment = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Updated a Department with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    req.body.DepartmentId = req.params.id;
    const result = await putDepartment(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
