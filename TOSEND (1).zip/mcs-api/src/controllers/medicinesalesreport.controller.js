import {
  getMedicineSalesReportListService,
  getMedicineItemListService,
  getMedicineTypeListService,
} from "../services/medicinesalesreport.service.js";

import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const medicinesalesreportController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Medicine Sales Report",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMedicineSalesReportListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const medicineitemlistController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Item List Report",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMedicineItemListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const medicinetypelistController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Type List Report",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMedicineTypeListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
