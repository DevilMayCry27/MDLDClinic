import {
  getEmployeeListService,
  getLaboratoriesRecordsService,
  postLabRecordService,
} from "../services/laboratory.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const employeeListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Employee List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getEmployeeListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const LaboratoryListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Laboratory Record List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getLaboratoriesRecordsService(req.params.LABid);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const uploadLaboratoryPhotoController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Uploaded New Laboratory Record",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    console.log(req?.files);
    const result = await postLabRecordService(req?.body, req?.files);
    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
