import {
  getConsultationReportListService,
  getConsultationReportIllnessService,
  getDepartmentReportIllnessService,
} from "../services/consultationreport.service.js";

import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const consultationreportController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Consultation Report",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getConsultationReportListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const consultationillnessreportController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Illness Report",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getConsultationReportIllnessService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const consultationdepartmentreportController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Department Illness Report",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getDepartmentReportIllnessService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
