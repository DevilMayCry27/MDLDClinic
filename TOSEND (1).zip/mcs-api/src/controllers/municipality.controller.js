import { postTrailLog } from "../services/trail.service.js";
import { moduleType } from "../utils/constant.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { getMunicipalityList } from "./../services/municipality.service.js";

export const municipalityList = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Municipality List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMunicipalityList();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
