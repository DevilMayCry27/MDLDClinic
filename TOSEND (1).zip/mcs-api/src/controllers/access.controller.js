import {
  getWebFeatureAccessByPosition,
  postWebFeatureAccess,
  putWebFeatureAccess,
} from "../services/access.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const accessByPosition = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Position Access",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getWebFeatureAccessByPosition(req.params.id);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeAccess = async (req, res) => {
  try {
    const result = await postWebFeatureAccess(req.body);

    res.status(200).json(result);
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};

export const modifyAccessByPosition = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Updated a Position Access with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    for (const access of req.body.access) {
      await putWebFeatureAccess(access);
    }

    res.status(200).json({ message: "Position Access Updated!" });
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
