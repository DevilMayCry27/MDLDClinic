import {
  getMedicineApproverService,
  getAuthorizePersonelService,
  postMedicineApproverService,
  deleteAuthorizePersonelService,
} from "../services/medicineapprover.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const MedicineApproverController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Medicine Approver List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMedicineApproverService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const AuthorizePersonelController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Authorize Personel List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getAuthorizePersonelService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeMedicineApproverController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Added New Medicine Approver",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postMedicineApproverService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const destroyAuthorizePersonelController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Deleted a Authorized Personel with ID: ${req.params.ID}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await deleteAuthorizePersonelService(req.params.ID);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
