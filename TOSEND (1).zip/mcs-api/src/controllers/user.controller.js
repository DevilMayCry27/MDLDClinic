import { getUserList, postUser, putUser, deleteUser } from '../services/user.service.js';
import { postTrailLog } from '../services/trail.service.js';
import { getLocalIpAddress } from '../utils/ip.js';
import { moduleType } from '../utils/constant.js';

export const userList = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail = {
        module: moduleType.admin,
        action: "View User List",
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        const result = await getUserList();
        
        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}

export const storeUser = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail =     {
        module: moduleType.admin,
        action: "Created New User",
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        const result = await postUser(req.body);

        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}

export const destroyUser = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail =     {
        module: moduleType.admin,
        action: `Deleted a User with Id: ${req.params.id}`,
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        const result = await deleteUser(req.params.id);

        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}

export const modifyUser = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail =     {
        module: moduleType.admin,
        action: `Updated a User with Id: ${req.params.id}`,
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        req.body.UserId = req.params.id;
        const result = await putUser(req.body);

        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}