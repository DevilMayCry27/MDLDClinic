import {
  getOrderNumberService,
  getAllMedicineOrderListService,
  getMedicineOrderListService,
  postMedicineOrderListService,
} from "../services/medicineorders.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const OrderNumberController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Order Number List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getOrderNumberService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const AllMedicineOrderListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Medicine Order List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getAllMedicineOrderListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const MedicineOrderListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Medicine Order List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMedicineOrderListService(req.params.MorderId);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeMedicineOrderController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Created New Medicine Order",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postMedicineOrderListService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
