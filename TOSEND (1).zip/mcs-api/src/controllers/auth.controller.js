import { authorized } from "../services/auth.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getUserProfile } from "../services/profile.service.js";
import { getWebFeatureAccessByPosition } from "../services/access.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";
import { verifyToken } from "../utils/jwt.js";

export const login = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.auth,
    action: "Portal Login",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const auth = await authorized(req.body);
    res.status(auth?.token ? 200 : 401).json(auth);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const userAccess = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    const { id } = verifyToken(token);

    const profile = await getUserProfile(id);

    const access = await getWebFeatureAccessByPosition(profile[0].UserLevel);

    res.status(200).json({
      profile: profile[0],
      apps: [
        ...new Set(
          access?.filter((y) => y.Retrieve)?.flatMap((x) => x.AppName)
        ),
      ],
      admin: access.filter((element) => element.Menu === 1),
      reference: access.filter((element) => element.Menu === 2),
      general: access.filter((element) => element.Menu === 3),
      report: access.map((x) => {
        return { WebFeatureId: x.WebFeatureId, Menu: 4, Retrieve: x.Report };
      }),
    });
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
};
