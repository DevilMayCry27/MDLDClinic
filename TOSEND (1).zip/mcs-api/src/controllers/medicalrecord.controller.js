import { getMedicalRecordListService } from "../services/medicalrecord.service.js";

import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const medicalrecordController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Consultation Report",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMedicalRecordListService(req.params.MRID);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
