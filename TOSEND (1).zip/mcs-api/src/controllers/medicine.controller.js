import {
  getMedicineList,
  postMedicine,
  putMedicine,
  deleteMedicine,
} from "../services/medicine.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const medicineList = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Medicine List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getMedicineList();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeMedicine = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Created New Medicine",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postMedicine(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const destroyMedicine = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Deleted a Medicine with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await deleteMedicine(req.params.id);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const modifyMedicine = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Updated a Medicine with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    req.body.MedicineId = req.params.id;
    const result = await putMedicine(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
