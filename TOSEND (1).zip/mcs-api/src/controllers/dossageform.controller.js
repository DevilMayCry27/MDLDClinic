import { getDossageFormList, postDossageForm, putDossageForm, deleteDossageForm } from '../services/dossageform.service.js';
import { postTrailLog } from '../services/trail.service.js';
import { getLocalIpAddress } from '../utils/ip.js';
import { moduleType } from '../utils/constant.js';

export const dossageFormList = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail = {
        module: moduleType.admin,
        action: "View Dossage Form List",
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        const result = await getDossageFormList();
        
        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}

export const storeDossageForm = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail = {
        module: moduleType.admin,
        action: "Created New Dossage Form",
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        const result = await postDossageForm(req.body);

        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}

export const destroyDossageForm = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail =     {
        module: moduleType.admin,
        action: `Deleted a Dossage Form with Id: ${req.params.id}`,
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        const result = await deleteDossageForm(req.params.id);

        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}

export const modifyDossageForm = async(req, res) => {
    const userLocalIp = getLocalIpAddress(req.clientIp);
    let trail = {
        module: moduleType.admin,
        action: `Updated a Dossage Form with Id: ${req.params.id}`,
        status: 1,
        ip_address: userLocalIp,
    }

    try {
        req.body.DossageFormId = req.params.id;
        const result = await putDossageForm(req.body);

        res.status(200).json(result);
    } catch (error) {
        trail.status = 0;
        res.status(409).json({ message: error.message });
    }

    await postTrailLog(trail);
}