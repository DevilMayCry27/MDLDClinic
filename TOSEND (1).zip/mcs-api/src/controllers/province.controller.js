import {
  getFilteredProvinceListService,
  getProvinceListService,
  postProvinceService,
  putProvinceService,
  deleteProvinceService,
  getProvinceByProvincenameService,
} from "../services/province.service.js";
import { postTrailLog } from "../services/trail.service.js";
import { getLocalIpAddress } from "../utils/ip.js";
import { moduleType } from "../utils/constant.js";

export const provinceListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Province List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getProvinceListService();

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const provinceFilteredListController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Filtered Province List",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getFilteredProvinceListService(req.params.PNo);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const provinceNameController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "View Province Duplicate",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await getProvinceByProvincenameService(req.params.name);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const storeProvinceController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: "Created New Province",
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await postProvinceService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const destroyProvinceController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Deleted a Province with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    const result = await deleteProvinceService(req.params.id);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};

export const modifyProvinceController = async (req, res) => {
  const userLocalIp = getLocalIpAddress(req.clientIp);
  let trail = {
    module: moduleType.admin,
    action: `Updated a Province with Id: ${req.params.id}`,
    status: 1,
    ip_address: userLocalIp,
  };

  try {
    req.body.ID = req.params.id;
    const result = await putProvinceService(req.body);

    res.status(200).json(result);
  } catch (error) {
    trail.status = 0;
    res.status(409).json({ message: error.message });
  }

  await postTrailLog(trail);
};
