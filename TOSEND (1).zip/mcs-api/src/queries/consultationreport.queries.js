export const getConsultationReportListQuery = () => {
  let q = `
  select WebConsultation.CreatedAt, FirstName, MiddleName, LastName, Department.Name AS Department, UserId, WebConsultation.Complaint, WebConsultation.Diagnosis, WebConsultation.Recommendation, WebConsultation.Physician
  from [ClinicPatients]
  inner join WebConsultation ON WebConsultation.UserId = [ClinicPatients].ID
  inner join Department ON Department.ID = [ClinicPatients].DepartmentID
  ORDER BY 
    CreatedAt DESC;`;
  return q;
};

export const getConsultationReportIllnessQuery = () => {
  let q = `
  SELECT 
  Complaint, Department, CreatedAt,
  COUNT(*) AS Count
FROM 
  (
  SELECT 
      WebConsultation.CreatedAt, 
      WebConsultation.Complaint,
      Department.Name AS Department
  FROM 
      [ClinicPatients]
  INNER JOIN 
      WebConsultation ON WebConsultation.UserId = [ClinicPatients].ID
  INNER JOIN 
      Department ON Department.ID = [ClinicPatients].DepartmentId
  ) AS SubQuery
GROUP BY 
  Complaint, Department, CreatedAt
ORDER BY 
    CreatedAt DESC;
`;
  return q;
};

export const getDepartmentReportIllnessQuery = () => {
  let q = `
  SELECT 
  Gender, CreatedAt,
  COUNT(*) AS Count
FROM 
  (
  SELECT 
      WebConsultation.Complaint,
      WebConsultation.CreatedAt, 
      Department.Name AS Department,
      Gender.Name AS Gender
  FROM 
      [ClinicPatients]
  INNER JOIN 
      WebConsultation ON WebConsultation.UserId = [ClinicPatients].ID
  INNER JOIN 
      Department ON Department.ID = [ClinicPatients].DepartmentID
  INNER JOIN 
      Gender ON Gender.ID = [ClinicPatients].GenderID
  ) AS SubQuery
GROUP BY 
  Gender, CreatedAt
ORDER BY 
    CreatedAt DESC;
    `;
  return q;
};
