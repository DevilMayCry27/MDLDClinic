export const getBloodTypeListQuery = () => {
  let q = `SELECT * FROM BloodType WHERE BloodType.Status < 2`;

  return q;
};

export const postBloodTypeQuery = (BloodType, Status) => {
  let q = `INSERT INTO BloodType (Name,Status) VALUES ('${BloodType}',${Status})`;

  return q;
};

export const putBloodTypeQuery = (ID, BloodType, Status) => {
  let q = `UPDATE BloodType SET Name = '${BloodType}', Status = ${Status}  WHERE ID = ${ID}`;

  return q;
};

export const deleteBloodTypeQuery = (BloodTypeId) => {
  let q = `UPDATE BloodType SET Status = 2 WHERE ID = ${BloodTypeId}`;

  return q;
};
