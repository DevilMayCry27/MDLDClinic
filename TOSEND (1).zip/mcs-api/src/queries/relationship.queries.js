export const getRelationListQuery = () => {
  let q = `SELECT * FROM Relationship WHERE Relationship.Status < 2`;

  return q;
};

export const postRelationQuery = (Relation, Status) => {
  let q = `INSERT INTO Relationship (Name,Status) VALUES ('${Relation}',${Status})`;

  return q;
};

export const putRelationQuery = (ID, Relation, Status) => {
  let q = `UPDATE Relationship SET Name = '${Relation}', Status = ${Status}  WHERE ID = ${ID}`;

  return q;
};

export const deleteRelationQuery = (RelationId) => {
  let q = `UPDATE Relationship SET Status = 2 WHERE ID = ${RelationId}`;

  return q;
};
