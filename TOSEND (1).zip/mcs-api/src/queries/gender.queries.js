export const getGenderListQuery = () => {
  let q = `SELECT * FROM Gender WHERE Gender.Status < 2`;

  return q;
};

export const postGenderQuery = (Name, Status) => {
  let q = `INSERT INTO Gender (Name,Status) VALUES ('${Name}',${Status})`;

  return q;
};

export const putGenderQuery = (ID, Name, Status) => {
  let q = `UPDATE Gender SET Name = '${Name}', Status = ${Status}  WHERE ID = ${ID}`;

  return q;
};

export const deleteGenderQuery = (GenderId) => {
  let q = `UPDATE Gender SET Status = 2 WHERE ID = ${GenderId}`;

  return q;
};
