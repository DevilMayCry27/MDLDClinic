export const getMunicipalityListQuery = () => {
  return `SELECT * FROM Municipality ORDER BY Name ASC;`;
};
