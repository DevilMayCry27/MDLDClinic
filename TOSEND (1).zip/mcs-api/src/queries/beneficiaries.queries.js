export const getBeneficiariesListQuery = (PID) => {
  let q = `SELECT 
  Beneficiaries.ID AS BID,
  [ClinicPatients].ID, 
  Beneficiaries.FirstName, 
  Beneficiaries.MiddleName, 
  Beneficiaries.LastName, 
  Relationship.ID AS RelationId,
  Relationship.Name,
  Country.ID AS CountryId,
  Country.CountryName,
  Region.ID AS RegionId,
  Region.RegionName,
  Province.ID AS ProvinceId,
  Province.Name AS ProvinceName,
  City.ID AS CityId,
  City.CityName,
  Beneficiaries.Baranggay,
  Beneficiaries.ContactNumber,
  Beneficiaries.Status, 
  Beneficiaries.CreatedAt
  FROM [ClinicPatients] 
  LEFT JOIN Beneficiaries ON Beneficiaries.EmployeeId = [ClinicPatients].ID
  LEFT JOIN Relationship ON Relationship.id = Beneficiaries.RelationshipId
  LEFT JOIN Country ON Country.ID = Beneficiaries.CountryId
  LEFT JOIN Region ON Region.ID = Beneficiaries.RegionId
  LEFT JOIN Province ON Province.ID = Beneficiaries.ProvinceId
  LEFT JOIN City ON City.ID = Beneficiaries.CityId
  WHERE [ClinicPatients].ID = ${PID}`;

  return q;
};

export const postBeneficiariesQuery = (
  EmployeeId,
  FirstName,
  MiddleName,
  LastName,
  RelationshipId,
  CountryId,
  RegionId,
  ProvinceId,
  CityId,
  Baranggay,
  ContactNumber,
  Status
) => {
  let q = `INSERT INTO Beneficiaries (EmployeeId, FirstName, MiddleName, LastName , RelationshipId, CountryId, RegionId, ProvinceId, CityId, Baranggay, ContactNumber, Status) VALUES (${EmployeeId},'${FirstName}','${MiddleName}','${LastName}',${RelationshipId},${CountryId},${RegionId},${ProvinceId},${CityId},${Baranggay},${ContactNumber},${Status})`;

  return q;
};

export const putBeneficiariesQuery = (
  EmployeeId,
  FirstName,
  MiddleName,
  LastName,
  RelationshipId,
  CountryId,
  RegionId,
  ProvinceId,
  CityId,
  Baranggay,
  ContactNumber,
  Status,
  ID
) => {
  let q = `UPDATE Beneficiaries SET EmployeeId='${EmployeeId}', FirstName='${FirstName}', MiddleName='${MiddleName}', LastName='${LastName}', RelationshipId=${RelationshipId}, CountryId=${CountryId}, RegionId=${RegionId}, ProvinceId=${ProvinceId}, CityId=${CityId}, Baranggay=${Baranggay}, ContactNumber=${ContactNumber}, Status=${Status} WHERE ID = ${ID}`;

  return q;
};

export const deleteBeneficiariesQuery = (ID) => {
  let q = `UPDATE Beneficiaries SET Status=2 WHERE ID = ${ID}`;
  return q;
};
