export const getClinicPatientListQuery = () => {
  let q = `SELECT 
    ClinicPatients.ID AS CPID,
    ClinicPatients.EmployeeCode,
    ClinicPatients.FirstName,
    ClinicPatients.MiddleName,
    ClinicPatients.LastName,
    ClinicPatients.GenderID,
    Gender.Name AS Gender,
    ClinicPatients.BirthDate,
    ClinicPatients.CountryID,
    Country.CountryName AS Country,
    ClinicPatients.RegionID,
    Region.RegionName AS Region,
    ClinicPatients.ProvinceID,
    Province.Name AS Province,
    ClinicPatients.MunicipalityID,
    City.CityName as Municipality,
    ClinicPatients.Street,
    ClinicPatients.CivilStatusID,
    CivilStatus.Name AS CivilStatus,
    ClinicPatients.BloodTypeID,
    BloodType.Name AS BloodType,
    ClinicPatients.ContactNumber,
    ClinicPatients.HealthCareNo,
    ClinicPatients.SSSNo,
    ClinicPatients.PhNo,
    ClinicPatients.TINNo,
    ClinicPatients.PagibigNo,
    ClinicPatients.Email,
    ClinicPatients.DepartmentID,
    Department.Name AS Department,
    ClinicPatients.DepartmentSection,
    ClinicPatientsPass.UserName,
    DepartmentSection.Name AS Section
    FROM ClinicPatients
    INNER JOIN Gender ON Gender.ID = ClinicPatients.GenderID
    INNER JOIN Country ON Country.ID = ClinicPatients.CountryID
    INNER JOIN Region ON Region.ID = ClinicPatients.RegionID
    INNER JOIN Province ON Province.ID = ClinicPatients.ProvinceID
    INNER JOIN City ON City.ID = ClinicPatients.MunicipalityID
    INNER JOIN CivilStatus ON CivilStatus.ID = ClinicPatients.CivilStatusID
    INNER JOIN BloodType ON BloodType.ID = ClinicPatients.BloodTypeID
    INNER JOIN Department ON Department.ID = ClinicPatients.DepartmentID
    INNER JOIN DepartmentSection ON DepartmentSection.ID = ClinicPatients.DepartmentSection
    INNER JOIN ClinicPatientsPass ON ClinicPatientsPass.EmployeeCode = ClinicPatients.EmployeeCode
    WHERE ClinicPatients.Status <> 2`;

  return q;
};

export const isUsernameExistQuery = (un) => {
  let q = `SELECT * FROM ClinicPatientsPass WHERE UserName = '${un}'`;

  return q;
};

export const postClinicPatientPassQuery = (
  EmployeeCode,
  UserLevel,
  UserName,
  Password,
  Status
) => {
  let q = `INSERT INTO ClinicPatientsPass (EmployeeCode, UserLevel, UserName,Password,Status) VALUES ('${EmployeeCode}','${UserLevel}','${UserName}','${Password}',${Status})`;

  return q;
};

export const postClinicPatientQuery = (
  EmployeeCode,
  FirstName,
  MiddleName,
  LastName,
  Gender,
  Country,
  Region,
  Province,
  Municipality,
  Street,
  CivilStatus,
  BloodType,
  ContactNumber,
  HealthCareNo,
  SSSNo,
  PhNo,
  TINNo,
  PagibigNo,
  Email,
  Department,
  Section,
  Status
) => {
  let q = `INSERT INTO ClinicPatients (
    EmployeeCode, FirstName, MiddleName, LastName , GenderID,
    CountryID, RegionID, ProvinceID, MunicipalityID, Street, CivilStatusID,
    BloodTypeID, ContactNumber, HealthCareNo, SSSNo, PhNo, TINNo, PagibigNo,
    Email, DepartmentID, DepartmentSection, Status) 
    VALUES ('${EmployeeCode}','${FirstName}','${MiddleName}','${LastName}',
    ${Gender},${Country},${Region},${Province},
    ${Municipality},'${Street}',${CivilStatus},${BloodType},'${ContactNumber}',
    '${HealthCareNo}','${SSSNo}','${PhNo}','${TINNo}','${PagibigNo}',
    '${Email}', ${Department}, ${Section}, ${Status})`;

  return q;
};

export const putClinicPatientsQuery = (
  EmployeeCode,
  FirstName,
  MiddleName,
  LastName,
  Gender,
  Country,
  Region,
  Province,
  Municipality,
  Street,
  CivilStatus,
  BloodType,
  ContactNumber,
  HealthCareNo,
  SSSNo,
  PhNo,
  TINNo,
  PagibigNo,
  Email,
  Department,
  Section,
  Status,
  ID
) => {
  let q = `UPDATE ClinicPatients SET EmployeeCode='${EmployeeCode}', 
  FirstName='${FirstName}', MiddleName='${MiddleName}', LastName='${LastName}', 
  GenderID=${Gender}, CountryID=${Country}, RegionID=${Region}, 
  ProvinceID=${Province}, MunicipalityID=${Municipality}, Street='${Street}', 
  CivilStatusID=${CivilStatus}, BloodTypeID=${BloodType}, ContactNumber='${ContactNumber}'
  , HealthCareNo='${HealthCareNo}', SSSNo='${SSSNo}', PhNo='${PhNo}'
  , TINNo='${TINNo}', PagibigNo='${PagibigNo}', Email='${Email}', DepartmentID=${Department}
  , DepartmentSection=${Section}, Status=${Status} WHERE ID = ${ID}`;

  return q;
};

export const deleteClinicPatientsQuery = (id) => {
  let q = `UPDATE ClinicPatients SET Status=2 WHERE ID = ${id}`;

  return q;
};
