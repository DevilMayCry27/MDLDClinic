export const getMedicineSalesReportListQuery = () => {
  let q = `
  SELECT 
  MedicineOrders.OrderId,
  MedicineOrders.Item,
  ClinicPatients.FirstName,
  ClinicPatients.MiddleName,
  ClinicPatients.LastName,
  Department.Name AS Department,
  MedicineOrders.Type,
  MedicineOrders.Status,
  MedicineOrders.Remarks,
  MedicineOrders.CreatedAt
FROM 
  MedicineOrders
INNER JOIN 
  ClinicPatients ON ClinicPatients.ID = MedicineOrders.EmployeeId
INNER JOIN 
  Department ON Department.ID = ClinicPatients.DepartmentId
WHERE 
  MedicineOrders.Status NOT IN (1, 2)
ORDER BY 
  MedicineOrders.CreatedAt DESC
`;
  return q;
};

export const getMedicineItemListQuery = () => {
  let q = `
  SELECT 
  Item, CreatedAt,
  COUNT(*) AS Qty
FROM 
  (
  SELECT 
      MedicineOrders.CreatedAt, 
      MedicineOrders.Item
  FROM 
      MedicineOrders
  WHERE 
      Status NOT IN (1, 2)
  ) AS SubQuery
GROUP BY 
  Item, CreatedAt
ORDER BY 
  CreatedAt DESC;
  `;
  return q;
};

export const getMedicineTypeListQuery = () => {
  let q = `
      SELECT 
      Type, CreatedAt,
      COUNT(*) AS Qty
    FROM 
      (
      SELECT 
          MedicineOrders.CreatedAt, 
          MedicineOrders.Type
      FROM 
          MedicineOrders
          WHERE 
          Status NOT IN (1, 2)
      ) AS SubQuery
    GROUP BY 
    Type, CreatedAt
    ORDER BY 
        CreatedAt DESC;
    `;
  return q;
};
