export const getCompanyListQuery = () => {
  let q = `SELECT * FROM Company WHERE Company.Status < 2`;

  return q;
};

export const postCompanyQuery = (CompanyName, CompanyDesc, Status) => {
  let q = `INSERT INTO Company (CompanyName,CompanyDesc,Status) VALUES ('${CompanyName}','${CompanyDesc}',${Status})`;

  return q;
};

export const putCompanyQuery = (
  CompanyId,
  CompanyName,
  CompanyDesc,
  Status
) => {
  let q = `UPDATE Company SET CompanyName = '${CompanyName}', CompanyDesc = '${CompanyDesc}', Status = ${Status}  WHERE ID = ${CompanyId}`;

  return q;
};

export const deleteCompanyQuery = (CompanyId) => {
  let q = `UPDATE Company SET Status = 2 WHERE ID = ${CompanyId}`;

  return q;
};
