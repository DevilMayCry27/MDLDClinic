export const getUserByIdQuery = (userId) => {
  return `SELECT ClinicPatientsPass.ID,
  ClinicPatientsPass.ID as EmployeeId,
  ClinicPatients.MunicipalityID as MunicipalityId,
  ClinicPatients.ProvinceID as ProvinceId,
  Department.Name as Department,
  DepartmentSection.Name as Section,
  ClinicPatients.FirstName,
  ClinicPatients.MiddleName,
  ClinicPatients.LastName,
  ClinicPatients.EmployeeCode,
  Gender.Name as Gender,
  ClinicPatients.ContactNumber,
  ClinicPatients.Email,
  ClinicPatients.Street,
  City.CityName as Municipality,
  Province.Name as Province
FROM ClinicPatientsPass
  INNER JOIN ClinicPatients ON ClinicPatients.ID = ClinicPatientsPass.ID
  INNER JOIN Gender ON Gender.ID = ClinicPatients.GenderID
  INNER JOIN City  ON City.ID = ClinicPatients.MunicipalityID
  INNER JOIN Province ON Province.ID = ClinicPatients.ProvinceID
  INNER JOIN Department ON Department.ID = ClinicPatients.DepartmentID
  INNER JOIN DepartmentSection ON DepartmentSection.ID = ClinicPatients.DepartmentSection
WHERE ClinicPatientsPass.ID = ${userId};`;
};

export const getCurrentUserInfoByUserIdQuery = (userId) => {
  return `SELECT ClinicPatients.ID,
  ClinicPatients.EmployeeCode,
  ClinicPatients.FirstName,
  ClinicPatients.MiddleName,
  ClinicPatients.LastName,
ClinicPatients.HealthCareNo,
  ClinicPatients.SSSNo,
  ClinicPatients.PhNo,
  ClinicPatients.TINNo,
  ClinicPatients.PagibigNo,
  Gender.Name as Gender,
  ClinicPatients.ContactNumber,
  ClinicPatients.Email,
  ClinicPatients.Street,
  ClinicPatients.BloodTypeID,
  ClinicPatients.CivilStatusID as CivilStatusID,
  CivilStatus.Name as CivilStatus,
  ClinicPatients.CountryID as CountryID,
  Country.CountryName as Country,
  ClinicPatients.RegionID as RegionID,
  Region.RegionName as Region,
  ClinicPatients.ProvinceID as ProvinceID,
  Province.Name as Province,
  ClinicPatients.MunicipalityID as MunicipalityID,
  City.CityName as City,
  Department.ID as DepartmentID,
  Department.Name as Department,
  DepartmentSection.Name as Section
FROM ClinicPatientsPass
LEFT JOIN ClinicPatients ON ClinicPatients.ID = ClinicPatientsPass.ID
LEFT JOIN Gender ON Gender.ID = ClinicPatients.GenderID
LEFT JOIN CivilStatus ON CivilStatus.ID = ClinicPatients.CivilStatusID
LEFT JOIN Country ON Country.ID = ClinicPatients.CountryID
LEFT JOIN Region ON Region.ID = ClinicPatients.RegionID
LEFT JOIN Province ON Province.ID = ClinicPatients.ProvinceID
LEFT JOIN City ON City.ID = ClinicPatients.MunicipalityID
LEFT JOIN Department ON Department.ID = ClinicPatients.DepartmentID
LEFT JOIN DepartmentSection ON DepartmentSection.ID = ClinicPatients.DepartmentSection
WHERE ClinicPatientsPass.ID = '${userId}';`;
};

export const updatePasswordQuery = (userId, username, hashPassword) => {
  return `UPDATE ClinicPatientsPass SET Password = '${hashPassword}' WHERE ID = '${userId}' AND UserName = '${username}'`;
};

export const updateProfileByCurrentUserQuery = (
  FirstName,
  MiddleName,
  LastName,
  ContactNo,
  StreetNo,
  Baranggay,
  MunicipalityID,
  ProvinceID,
  userID
) => {
  return `  UPDATE ClinicPatients
  SET FirstName = '${FirstName}',
      MiddleName = '${MiddleName}',
      LastName = '${LastName}',
      ContactNo = '${ContactNo}',
      StreetNo = '${StreetNo}',
      Baranggay = '${Baranggay}',
      MunicipalityID = ${MunicipalityID},
      ProvinceID = ${ProvinceID}
  WHERE ID = ${userID};`;
};
