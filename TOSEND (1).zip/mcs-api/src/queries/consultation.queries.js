export const getConsultationListQuery = (ConsId) => {
  let q = `
    SELECT 
    WebConsultation.ID AS ConsID,
    [ClinicPatients].ID AS UID,
    WebConsultation.Complaint,
    WebConsultation.Bp,
    WebConsultation.Temp,
    WebConsultation.Rr,
    WebConsultation.Pr,
    WebConsultation.Diagnosis,
    WebConsultation.Recommendation,
    WebConsultation.Physician,
    WebConsultation.Status,
    WebConsultation.CreatedAt
FROM 
    [ClinicPatients]
INNER JOIN 
    WebConsultation ON WebConsultation.UserId = [ClinicPatients].ID
WHERE 
    WebConsultation.Status <> 2 AND [ClinicPatients].ID = ${ConsId}`;
  return q;
};

export const postConsultationQuery = (
  UserId,
  Illness,
  Bp,
  Temp,
  Rr,
  Pr,
  Diagnosis,
  Recommendation,
  Physician
) => {
  let q = `INSERT INTO WebConsultation (UserId,Complaint,Bp,Temp,Rr,Pr,Diagnosis,Recommendation,Physician, Status) VALUES (${UserId},'${Illness}','${Bp}','${Temp}','${Rr}','${Pr}','${Diagnosis}','${Recommendation}','${Physician}',${1})`;

  return q;
};

export const putConsultationQuery = (
  ConsID,
  Illness,
  Bp,
  Temp,
  Rr,
  Pr,
  Diagnosis,
  Recommendation,
  Physician
) => {
  let q = `UPDATE WebConsultation SET Complaint = '${Illness}', Bp = '${Bp}', Temp = '${Temp}', Rr = '${Rr}', Pr = '${Pr}', Diagnosis = '${Diagnosis}', Recommendation = '${Recommendation}', Physician = '${Physician}'  WHERE ID = ${ConsID}`;

  return q;
};

export const deleteConsultationQuery = (ConsId) => {
  let q = `UPDATE WebConsultation SET Status = 2 WHERE ID = ${ConsId}`;

  return q;
};
