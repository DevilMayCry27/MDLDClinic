export const getProvinceListQuery = () => {
  let q = `SELECT 
  [Province].ID as ProvinceId, 
  Region.ID AS RegionId,
  Region.RegionName,
  [Province].Name, 
  [Province].Status
FROM [Province] 
INNER JOIN Region ON Region.id = Province.RegionId
WHERE [Province].Status <> 2`;

  return q;
};

export const getFilteredProvinceListQuery = (PNo) => {
  let q = `SELECT 
  [Province].ID as ProvinceId, 
  Region.ID AS RegionId,
  Region.RegionName,
  [Province].Name, 
  [Province].Status
FROM [Province] 
INNER JOIN Region ON Region.id = Province.RegionId
WHERE Region.ID = ${PNo} AND [Province].Status < 2`;

  return q;
};

export const getProvinceByProvincenameQuery = (cn) => {
  let q = `SELECT Name FROM [Province] WHERE Name = '${cn}' and Status = 1`;
  return q;
};

export const postProvinceQuery = (RegionId, ProvinceName, Status) => {
  let q = `INSERT INTO Province ( RegionId, Name, Status) VALUES ( ${RegionId},'${ProvinceName}',${Status})`;

  return q;
};

export const putProvinceQuery = (ProvinceName, Status, RegionId, ID) => {
  let q = `UPDATE Province SET Name='${ProvinceName}', Status=${Status}, RegionId=${RegionId} WHERE ID = ${ID}`;

  return q;
};

export const deleteProvinceQuery = (province_id) => {
  let q = `UPDATE Province SET Status= 2 WHERE ID = ${province_id}`;

  return q;
};

export const putCity4Query = (Status, ProvinceId) => {
  let q = `UPDATE City SET Status=${Status} WHERE ProvinceId = ${ProvinceId}`;

  return q;
};
