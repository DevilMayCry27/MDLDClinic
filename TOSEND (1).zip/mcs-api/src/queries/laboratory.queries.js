export const getEmployeeListQuery = () => {
  let q = `SELECT 
  ClinicPatients.ID, 
  ClinicPatients.EmployeeCode, 
    ClinicPatients.FirstName, 
    ClinicPatients.MiddleName, 
    ClinicPatients.LastName, 
    ClinicPatients.HealthCareNo, 
    ClinicPatients.PhNo, 
    ClinicPatients.SSSNo, 
    ClinicPatients.TINNo, 
    ClinicPatients.PagibigNo, 
    ClinicPatients.BloodTypeID, 
    ClinicPatients.Status, 
    ClinicPatients.Street,
    Department.ID AS DepartmentId,
    Department.Name AS Department,
    DepartmentSection.ID AS SectionId,
    DepartmentSection.Name AS Section
    FROM ClinicPatients
    INNER JOIN Department ON Department.ID = ClinicPatients.DepartmentID
    INNER JOIN DepartmentSection ON DepartmentSection.ID = ClinicPatients.DepartmentSection
    WHERE ClinicPatients.Status = 1`;

  return q;
};

export const getLaboratoriesRecordsQuery = (LABid) => {
  let q = `SELECT
  LaboratoryRecords.ImageCode,
  LaboratoryRecords.EmployeeId,
  LaboratoryRecords.CreatedAt,
  LaboratoryRecords.FilePath,
  LaboratoryRecords.OriginalName
  FROM LaboratoryRecords
  WHERE LaboratoryRecords.EmployeeId = ${LABid}`;

  return q;
};

export const postLabRecordQuery = (
  filename,
  EmployeeId,
  filepath,
  originalname
) => {
  let q = `INSERT INTO LaboratoryRecords (ImageCode,EmployeeId,Status, filepath, OriginalName) VALUES ('${filename}','${EmployeeId}',1,'${filepath}','${originalname}')`;

  return q;
};
