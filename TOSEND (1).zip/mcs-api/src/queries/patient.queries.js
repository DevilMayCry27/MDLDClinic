export const getPatientListQuery = () => {
  let q = `SELECT 
  ClinicPatients.ID, 
  ClinicPatients.EmployeeCode, 
  ClinicPatients.FirstName, 
  ClinicPatients.MiddleName, 
  ClinicPatients.LastName, 
  ClinicPatients.HealthCareNo, 
  ClinicPatients.PhNo, 
  ClinicPatients.SSSNo, 
  ClinicPatients.TINNo, 
  ClinicPatients.PagibigNo, 
  ClinicPatients.BloodTypeID, 
  ClinicPatients.Status, 
  ClinicPatients.Street,
  Gender.ID AS GenderID,
  Gender.Name AS GenderName,
  CivilStatus.ID AS CiviStatusID,
  CivilStatus.Name AS CivilStatus,
  Department.ID AS DepartmentId,
  Department.Name AS Department,
  DepartmentSection.ID AS SectionId,
  DepartmentSection.Name AS Section,
  Country.ID AS CountryID,
  Country.CountryName AS Country,
  Region.ID AS RegionID,
  Region.RegionName AS Region,
  Province.ID AS ProvinceID,
  Province.Name AS Province,
  City.ID AS CityID,
  City.CityName AS City
  FROM ClinicPatients
  INNER JOIN Gender ON Gender.ID = ClinicPatients.GenderID
  INNER JOIN CivilStatus ON CivilStatus.ID = ClinicPatients.CivilStatusId
  INNER JOIN Department ON Department.ID = ClinicPatients.DepartmentId
  INNER JOIN DepartmentSection ON DepartmentSection.ID = ClinicPatients.DepartmentSection
  INNER JOIN Country ON Country.ID = ClinicPatients.CountryID
  INNER JOIN Region ON Region.ID = ClinicPatients.RegionID
  INNER JOIN Province ON Province.ID = ClinicPatients.ProvinceID
  INNER JOIN City ON City.ID = ClinicPatients.MunicipalityID
  WHERE ClinicPatients.Status = 1`;

  return q;
};
