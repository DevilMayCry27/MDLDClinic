export const getEmployeeListQuery = () => {
  let q = `SELECT 
  ClinicPatients.ID, 
  ClinicPatients.EmployeeCode, 
  ClinicPatients.FirstName, 
  ClinicPatients.MiddleName, 
  ClinicPatients.LastName, 
  ClinicPatients.HealthCareNo, 
  ClinicPatients.PhNo, 
    ClinicPatients.SSSNo, 
    ClinicPatients.TINNo, 
    ClinicPatients.PagibigNo, 
    ClinicPatients.BloodTypeID, 
    ClinicPatients.Status, 
    ClinicPatients.Street,
    Department.ID AS DepartmentId,
    Department.Name AS Department,
    DepartmentSection.ID AS SectionId,
    DepartmentSection.Name AS Section
    FROM ClinicPatients
    INNER JOIN Department ON Department.ID = ClinicPatients.DepartmentID
    INNER JOIN DepartmentSection ON DepartmentSection.ID = ClinicPatients.DepartmentSection
    WHERE ClinicPatients.Status = 1`;

  return q;
};

export const getApeRecordsQuery = (APEid) => {
  let q = `SELECT
  ApeRecords.ImageCode,
  ApeRecords.EmployeeId,
  ApeRecords.CreatedAt,
  ApeRecords.FilePath,
  ApeRecords.OriginalName
  FROM ApeRecords
  WHERE ApeRecords.EmployeeId = ${APEid}`;

  return q;
};

export const postApeRecordQuery = (
  filename,
  EmployeeId,
  filepath,
  originalname
) => {
  let q = `INSERT INTO ApeRecords (ImageCode,EmployeeId,Status, filepath, OriginalName) VALUES ('${filename}','${EmployeeId}',1,'${filepath}','${originalname}')`;

  return q;
};
