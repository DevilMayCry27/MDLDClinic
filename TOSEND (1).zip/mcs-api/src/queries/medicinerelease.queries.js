export const getMedicineReleaseQuery = (UL) => {
  let q = `SELECT 
    MedicineOrders.ID AS OID,
    MedicineOrders.OrderId AS NID,
    ClinicPatients.ID AS MOID,
    ClinicPatients.FirstName,
    ClinicPatients.MiddleName,
    ClinicPatients.LastName,
    Department.Name AS Department,
    MedicineOrders.Qty,
    MedicineOrders.Item,
    MedicineOrders.Price,
    MedicineOrders.Amount,
    MedicineOrders.OrderId,
    MedicineOrders.Type AS TypeId,
    OrderType.OrderName,
    OrderStatusType.StatusName
  FROM MedicineOrders
  INNER JOIN ClinicPatients ON ClinicPatients.ID = MedicineOrders.EmployeeId
  INNER JOIN OrderType ON OrderType.ID = MedicineOrders.Type
  INNER JOIN Department ON Department.ID = ClinicPatients.DepartmentId
  INNER JOIN OrderStatusType ON OrderStatusType.ID = MedicineOrders.Status
  INNER JOIN (
      SELECT MAX(ID) AS MaxID
      FROM MedicineOrders
      WHERE STATUS <> 3
      GROUP BY OrderId
  ) max_mo ON MedicineOrders.ID = max_mo.MaxID
  WHERE MedicineOrders.STATUS <> 3 AND MedicineOrders.Status = ${UL}
  `;

  return q;
};

export const getUserLevelQuery = (AL) => {
  let q = `SELECT
  MedicineApprover.Level 
  FROM MedicineApprover
  LEFT JOIN Users ON Users.ID = MedicineApprover.UserId
  WHERE Users.Id = ${AL} AND MedicineApprover.Status <> 2 `;

  return q;
};

export const getApprovalOrderListQuery = (NorderID) => {
  let q = `SELECT
  MedicineOrders.ID AS OID,
  OrderId,
  Qty,
  Item,
  Price,
  Amount,
  Type AS TypeId,
  OrderType.OrderName
  FROM MedicineOrders 
  INNER JOIN OrderType ON OrderType.ID = MedicineOrders.Type
  WHERE OrderId = ${NorderID}`;

  return q;
};

export const putApprovalQuery = (AID) => {
  let q = `UPDATE MedicineOrders SET Status = 2  WHERE OrderId = ${AID}`;

  return q;
};

export const putReleaseQuery = (RID) => {
  let q = `UPDATE MedicineOrders SET Status = 3  WHERE OrderId = ${RID}`;

  return q;
};

export const putRejectQuery = (WID, Remarks) => {
  let q = `UPDATE MedicineOrders SET Remarks = '${Remarks}', Status = 4  WHERE OrderId = ${WID}`;

  return q;
};
