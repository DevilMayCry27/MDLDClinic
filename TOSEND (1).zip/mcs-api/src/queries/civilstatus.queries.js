export const getCivilStatusListQuery = () => {
  let q = `SELECT * FROM CivilStatus WHERE CivilStatus.Status < 2`;

  return q;
};

export const postCivilStatusQuery = (Name, Status) => {
  let q = `INSERT INTO CivilStatus (Name, Status) VALUES ('${Name}',${Status})`;

  return q;
};

export const putCivilStatusQuery = (ID, Name, Status) => {
  let q = `UPDATE CivilStatus SET Name = '${Name}', Status = ${Status}  WHERE ID = ${ID}`;

  return q;
};

export const deleteCivilStatusQuery = (CivilStatusId) => {
  let q = `UPDATE CivilStatus SET Status = 2 WHERE ID = ${CivilStatusId}`;

  return q;
};
