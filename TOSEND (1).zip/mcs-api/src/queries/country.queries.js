export const getCountryListQuery = () => {
  let q = `SELECT * FROM Country WHERE Country.Status < 2`;

  return q;
};

export const getCountryByCountrynameQuery = (cn) => {
  let q = `SELECT CountryName FROM [Country] WHERE CountryName = '${cn}' and Status = 1`;
  return q;
};

export const postCountryQuery = (CountryName, Status) => {
  let q = `INSERT INTO Country (CountryName,Status) VALUES ('${CountryName}',${Status})`;

  return q;
};

export const putCountryQuery = (CountryId, CountryName, Status) => {
  let q = `UPDATE Country SET CountryName = '${CountryName}', Status = ${Status}  WHERE ID = ${CountryId}`;

  return q;
};

export const deleteCountryQuery = (CountryId) => {
  let q = `UPDATE Country SET Status = 2 WHERE ID = ${CountryId}`;

  return q;
};

export const putRegion2Query = (Status, CountryId) => {
  let q = `UPDATE Region SET Status=${Status} WHERE CountryId = ${CountryId}`;

  return q;
};

export const deleteRegion2Query = (region_id) => {
  let q = `UPDATE Region SET Status= 2 WHERE CountryId = ${region_id}`;

  return q;
};

export const putProvince2Query = (Status, CountryId) => {
  let q = `UPDATE Province SET Status=${Status} WHERE CountryId = ${CountryId}`;

  return q;
};

export const deleteProvince2Query = (province_id) => {
  let q = `UPDATE Province SET Status= 2 WHERE CountryId = ${province_id}`;

  return q;
};

export const putCity2Query = (Status, CountryId) => {
  let q = `UPDATE City SET Status=${Status} WHERE CountryId = ${CountryId}`;

  return q;
};

export const deleteCity2Query = (city_id) => {
  let q = `UPDATE City SET Status= 2 WHERE CountryId = ${city_id}`;

  return q;
};
