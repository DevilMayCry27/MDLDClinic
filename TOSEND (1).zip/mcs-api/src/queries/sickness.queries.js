export const getSicknessListQuery = () => {
  let q = `SELECT * FROM Sickness WHERE Status <> 2`;

  return q;
};

export const postSicknessQuery = (Illness) => {
  let q = `INSERT INTO Sickness(Illness) VALUES ('${Illness}')`;

  return q;
};

export const putSicknessQuery = (Illness, SickID) => {
  let q = `UPDATE Sickness SET Illness = '${Illness}' WHERE ID = ${SickID}`;

  return q;
};

export const deleteSicknessQuery = (SickID) => {
  let q = `UPDATE Sickness SET Status=2 WHERE ID = ${SickID}`;

  return q;
};
