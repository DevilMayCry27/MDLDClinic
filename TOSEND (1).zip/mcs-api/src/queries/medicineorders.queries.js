export const getOrderNumberQuery = () => {
  let q = `SELECT 
  CASE 
      WHEN MAX(OrderId) IS NULL THEN 1 
      ELSE MAX(OrderId) + 1 
  END AS NextOrderID 
FROM 
  MedicineOrders
`;

  return q;
};

export const getAllMedicineOrderListQuery = () => {
  let q = `SELECT 
  MedicineOrders.ID AS OID,
  MedicineOrders.OrderId AS NID,
  ClinicPatients.ID AS MOID,
  ClinicPatients.FirstName,
  ClinicPatients.MiddleName,
  ClinicPatients.LastName,
  Department.Name AS Department,
  MedicineOrders.Qty,
  MedicineOrders.Item,
  MedicineOrders.Price,
  MedicineOrders.Amount,
  MedicineOrders.CreatedAt,
  MedicineOrders.Remarks,
  MedicineOrders.OrderId,
  MedicineOrders.Type AS TypeId,
  OrderType.OrderName,
  OrderStatusType.StatusName
FROM MedicineOrders
INNER JOIN ClinicPatients ON ClinicPatients.ID = MedicineOrders.EmployeeId
INNER JOIN OrderType ON OrderType.ID = MedicineOrders.Type
INNER JOIN Department ON Department.ID = ClinicPatients.DepartmentId
INNER JOIN OrderStatusType ON OrderStatusType.ID = MedicineOrders.Status
INNER JOIN (
    SELECT MAX(ID) AS MaxID
    FROM MedicineOrders
    GROUP BY OrderId
) max_mo ON MedicineOrders.ID = max_mo.MaxID
ORDER BY MedicineOrders.CreatedAt DESC
`;

  return q;
};

export const getMedicineOrderListQuery = (MorderId) => {
  let q = `SELECT
  MedicineOrders.ID AS OID,
  OrderId,
  Qty,
  Item,
  Price,
  Amount,
  Type AS TypeId,
  OrderType.OrderName
  FROM MedicineOrders 
  INNER JOIN OrderType ON OrderType.ID = MedicineOrders.Type
  WHERE OrderId = ${MorderId}`;

  return q;
};

export const postMedicineOrderQuery = (
  EmployeeId,
  NextOrderID,
  TypeId,
  Qty,
  Item,
  Price,
  Amount
) => {
  let q = `INSERT INTO MedicineOrders (EmployeeId, OrderId, Type,Qty,Item,Price,Amount,Status) VALUES ('${EmployeeId}', ${NextOrderID}, ${TypeId},${Qty},'${Item}',${Price},${Amount},1)`;
  return q;
};
