export const getDepartmentListQuery = () => {
  // let q = `SELECT Department.ID, Department.Name, Department.Status FROM Department WHERE Department.Status < 2`;
  let q = `SELECT * FROM Department WHERE Status = 1 ORDER BY Name ASC;`;
  return q;
};

export const postDepartmentQuery = (Name, Status) => {
  let q = `INSERT INTO Department (Name,Status) VALUES ('${Name}',${Status})`;

  return q;
};

export const putDepartmentQuery = (DepartmentId, Name, Status) => {
  let q = `UPDATE Department SET Name = '${Name}', Status = ${Status}  WHERE ID = ${DepartmentId}`;

  return q;
};

export const deleteDepartmentQuery = (DepartmentId) => {
  let q = `UPDATE Department SET Status = 2 WHERE ID = ${DepartmentId}`;

  return q;
};
