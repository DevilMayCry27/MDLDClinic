export const getCityListQuery = () => {
  let q = `SELECT 
  [City].ID, 
  Province.ID AS ProvinceId,
  Province.Name,
  [City].CityName, 
  [City].Status
FROM [City] 
INNER JOIN Province ON Province.id = City.ProvinceId
WHERE [City].Status < 2`;

  return q;
};

export const getFilteredCityListQuery = (CNo) => {
  let q = `SELECT 
  [City].ID, 
  Province.ID AS ProvinceId,
  Province.Name,
  [City].CityName, 
  [City].Status
FROM [City] 
INNER JOIN Province ON Province.id = City.ProvinceId
WHERE Province.ID = ${CNo} AND [City].Status <> 2`;

  return q;
};

export const getCityByCitynameQuery = (cn) => {
  let q = `SELECT CityName FROM [City] WHERE CityName = '${cn}' and Status = 1`;
  return q;
};

export const postCityQuery = (ProvinceId, CityName, Status) => {
  let q = `INSERT INTO City (ProvinceId, CityName, Status) VALUES (${ProvinceId},'${CityName}',${Status})`;

  return q;
};

export const putCityQuery = (CityName, Status, ProvinceId, ID) => {
  let q = `UPDATE City SET CityName='${CityName}', Status=${Status}, ProvinceId=${ProvinceId} WHERE ID = ${ID}`;

  return q;
};

export const deleteCityQuery = (city_id) => {
  let q = `UPDATE City SET Status= 2 WHERE ID = ${city_id}`;

  return q;
};
