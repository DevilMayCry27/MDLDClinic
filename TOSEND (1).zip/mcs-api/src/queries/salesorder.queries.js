export const getEmployeeOrderListQuery = () => {
  let q = `SELECT 
  [ClinicPatients].ID AS EmID,
  [ClinicPatients].FirstName,
  [ClinicPatients].MiddleName,
  [ClinicPatients].LastName,
  Users.FullName,
  Department.Name AS Department,
  DepartmentSection.Name AS Section
  FROM ClinicPatients 
  INNER JOIN Users ON Users.EmployeeID = ClinicPatients.ID
  INNER JOIN Department ON Department.ID = [ClinicPatients].DepartmentId
  INNER JOIN DepartmentSection ON DepartmentSection.ID = [ClinicPatients].SectionId
  WHERE [ClinicPatients].STATUS = 1`;

  return q;
};
