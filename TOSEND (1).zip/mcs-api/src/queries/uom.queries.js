export const getUomListQuery = () => {
  let q = `SELECT * FROM Uom WHERE Uom.Status < 2`;

  return q;
};

export const postUomQuery = (Unit) => {
  let q = `INSERT INTO Uom (Unit) VALUES ('${Unit}')`;

  return q;
};

export const putUomQuery = (Unit, Status, UomId) => {
  let q = `UPDATE Uom SET Unit = '${Unit}', Status = ${Status} WHERE ID ='${UomId}'`;
  console.log(q, "QUERY TEST");
  return q;
};

export const deleteUomQuery = (UomId) => {
  let q = `UPDATE Uom SET Status = 2 WHERE ID = ${UomId}`;

  return q;
};
