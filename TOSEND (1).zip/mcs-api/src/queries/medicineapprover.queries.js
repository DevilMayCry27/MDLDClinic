export const getApproverQuery = () => {
  let q = `SELECT
  Users.ID AS UID,
  Users.FullName,
  ClinicPatients.ID AS EID,
  ClinicPatients.FirstName,
  ClinicPatients.MiddleName,
  ClinicPatients.LastName
  From Users
  INNER JOIN ClinicPatients ON ClinicPatients.ID = Users.EmployeeID
  WHERE ClinicPatients.Status = 1`;

  return q;
};

export const getAuthorizePersonelQuery = () => {
  let q = `SELECT * FROM MedicineApprover WHERE STATUS = 1`;

  return q;
};

export const postMedicineApproverQuery = (
  EmployeeId,
  UserId,
  FirstName,
  MiddleName,
  LastName,
  Level
) => {
  let q = `INSERT INTO MedicineApprover (EmployeeId, UserId, FirstName, MiddleName, LastName, Level) 
  VALUES ('${EmployeeId}', ${UserId}, '${FirstName}','${MiddleName}','${LastName}',${Level})`;
  return q;
};

export const deleteAuthorizePersonelQuery = (ID) => {
  let q = `UPDATE MedicineApprover SET Status = 2 WHERE ID = ${ID}`;

  return q;
};
