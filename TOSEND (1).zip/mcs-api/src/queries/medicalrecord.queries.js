export const getMedicalRecordListQuery = (MRID) => {
  let q = `
    select 
    WebConsultation.CreatedAt, UserId, WebConsultation.Complaint, WebConsultation.Diagnosis, WebConsultation.Recommendation, WebConsultation.Physician
    from [ClinicPatients]
    inner join WebConsultation ON WebConsultation.UserId = [ClinicPatients].ID
    WHERE [ClinicPatients].ID = ${MRID}`;
  return q;
};
