export const getSectionListQuery = () => {
  let q = `SELECT DepartmentSection.ID, DepartmentSection.DepartmentID, DepartmentSection.Name, DepartmentSection.Status FROM DepartmentSection WHERE DepartmentSection.Status < 2`;

  return q;
};

export const getFilteredSectionListQuery = (SNo) => {
  let q = `SELECT DepartmentSection.ID, DepartmentSection.DepartmentID, DepartmentSection.Name, DepartmentSection.Status FROM DepartmentSection WHERE DepartmentSection.DepartmentID = ${SNo} AND DepartmentSection.Status <> 2`;

  return q;
};

export const postSectionQuery = (Name, DepartmentID, Status) => {
  let q = `INSERT INTO DepartmentSection (Name, DepartmentID, Status) VALUES ('${Name}',${DepartmentID},${Status})`;

  return q;
};

export const putSectionQuery = (SectionId, Name, DepartmentID, Status) => {
  let q = `UPDATE DepartmentSection SET Name = '${Name}', DepartmentID = '${DepartmentID}', Status = '${Status}'  WHERE ID = '${SectionId}'`;

  return q;
};

export const deleteSectionQuery = (SectionId) => {
  let q = `UPDATE DepartmentSection SET Status=2 WHERE ID = ${SectionId}`;

  return q;
};
