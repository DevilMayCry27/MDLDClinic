export const getRegionListQuery = () => {
  let q = `SELECT 
    [Region].ID, 
    Country.ID AS CountryId,
    Country.CountryName,
    [Region].RegionName, 
    [Region].Status, 
    [Region].CreatedAt
    FROM [Region] 
    INNER JOIN Country ON Country.id = Region.CountryId
    WHERE [Region].Status < 2`;

  return q;
};

export const getFilteredRegionListQuery = (RNo) => {
  let q = `SELECT 
  [Region].ID, 
  Country.ID AS CountryId,
  Country.CountryName,
  [Region].RegionName, 
  [Region].Status, 
  [Region].CreatedAt
  FROM [Region] 
  INNER JOIN Country ON Country.id = Region.CountryId
  WHERE Country.ID = ${RNo} AND [Region].Status <> 2`;

  return q;
};

export const getRegionByRegionnameQuery = (rn) => {
  let q = `SELECT RegionName FROM [Region] WHERE RegionName = '${rn}' and Status = 1`;
  return q;
};

export const postRegionQuery = (CountryId, RegionName, Status) => {
  let q = `INSERT INTO Region (CountryId, RegionName, Status) VALUES (${CountryId},'${RegionName}',${Status})`;

  return q;
};

export const putRegionQuery = (RegionName, Status, CountryId, ID) => {
  let q = `UPDATE Region SET RegionName='${RegionName}', Status=${Status}, CountryId=${CountryId} WHERE ID = ${ID}`;

  return q;
};

export const deleteRegionQuery = (region_id) => {
  let q = `UPDATE Region SET Status= 2 WHERE ID = ${region_id}`;

  return q;
};
