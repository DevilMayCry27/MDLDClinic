import { verifyToken } from "../utils/jwt.js";

export const requireAuth = (req, res, next) => {
  const unauthMessage = "Unauthenticated!";
  const token = req.headers.authorization?.replace("Bearer ", "");

  const isVerified = token && verifyToken(token);

  if (!isVerified) {
    return res?.status(401).json({ message: unauthMessage });
  }

  req.user = isVerified;

  next();
};
