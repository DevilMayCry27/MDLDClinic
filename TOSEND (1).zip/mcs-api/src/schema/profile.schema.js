import { z } from "zod";

export const ChangePassSchema = z.object({
  oldPassword: z.string().min(1),
  newPassword: z.string().min(1),
});

export const updateProfileSchema = z.object({
  FirstName: z.string().min(1),
  MiddleName: z.string().min(1),
  LastName: z.string().min(1),
  Email: z.string().min(1),
  GenderID: z.string().min(1),
  ContactNoE: z.string().min(1),
  BloodTypeID: z.string().min(1),
  CountryId: z.string().min(1),
  RegionId: z.string().min(1),
  ProvinceId: z.string().min(1),
  CityId: z.string().min(1),
  Baranggay: z.string().min(1),
  MunicipalityID: z.number().min(1),
  ProvinceID: z.number().min(1),
});
