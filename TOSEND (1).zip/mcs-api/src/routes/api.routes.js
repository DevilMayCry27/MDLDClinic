import express from "express";

import * as profileController from "../controllers/profile.controller.js";
import * as authController from "../controllers/auth.controller.js";
import * as accessController from "../controllers/access.controller.js";
import * as positionController from "../controllers/position.controller.js";
import * as userController from "../controllers/user.controller.js";
import * as trailController from "../controllers/trail.controller.js";

import * as companyController from "../controllers/company.controller.js";
import * as departmentController from "../controllers/department.controller.js";
import * as sectionController from "../controllers/section.controller.js";
import * as genderController from "../controllers/gender.controller.js";
import * as civilstatusController from "../controllers/civilstatus.controller.js";
import * as bloodtypeController from "../controllers/bloodtype.controller.js";
import * as relationController from "../controllers/relation.controller.js";
import * as countryController from "../controllers/country.controller.js";
import * as regionController from "../controllers/region.controller.js";
import * as provinceController from "../controllers/province.controller.js";
import * as cityController from "../controllers/city.controller.js";
import * as beneficiariesController from "../controllers/beneficiaries.controller.js";
import * as municipalityController from "../controllers/municipality.controller.js";
import * as clinicpatientsController from "../controllers/clinicpatients.controller.js";

import * as patientController from "../controllers/patient.controller.js";
import * as consultationController from "../controllers/consultation.controller.js";
import * as medicineController from "../controllers/medicine.controller.js";
import * as consultationreportController from "../controllers/consultationreport.controller.js";
import * as dossageController from "../controllers/dossageform.controller.js";
import * as uomController from "../controllers/uom.controller.js";
import * as salesorderController from "../controllers/salesorder.controller.js";
import * as medicineorderController from "../controllers/medicineorder.controller.js";
import * as medicineapproverController from "../controllers/medicineapprover.controller.js";
import * as medicinereleaseController from "../controllers/medicinerelease.controller.js";
import * as apeController from "../controllers/ape.controller.js";
import * as laboratoryController from "../controllers/laboratory.controller.js";
import * as sicknessController from "../controllers/sickness.controller.js";
import * as medicinesalesreportController from "../controllers/medicinesalesreport.controller.js";

import * as medicalrecordController from "../controllers/medicalrecord.controller.js";

import { forumUpload,upload,ApeUpload, LaboratoryUpload } from "../utils/multer.js";

import { requireAuth } from "../middlewares/authMiddleware.js";
import { validateData } from "../middlewares/validationMiddleware.js";

import * as authSchema from "../schema/auth.schema.js";
import * as profileSchema from "../schema/profile.schema.js";

const apiRoutes = express.Router();

apiRoutes.group("/auth", (router) => {
  router.post(
    "/login",
    validateData(authSchema.AuthLoginSchema),
    authController.login
  );
  router.get("/access", requireAuth, authController.userAccess);
});

apiRoutes.group("/profile", (router) => {
  router.get("/", requireAuth, profileController.currentUserProfile);
  router.post(
    "/upload-photo",
    upload.single("ProfilePic"),
    profileController.uploadPhoto
  );
  router.put(
    "/update-info",
    requireAuth,
    validateData(profileSchema.updateProfileSchema),
    profileController.updateProfile
  );
  router.put(
    "/change-pass",
    requireAuth,
    validateData(profileSchema.ChangePassSchema),
    profileController.changePass
  );
});

apiRoutes.group("/user", (router) => {
  router.get("/", requireAuth, userController.userList);
  router.post("/", requireAuth, positionController.storePosition);
  router.put("/:id", requireAuth, positionController.modifyPosition);
  router.delete("/:id", requireAuth, positionController.destroyPosition);
});

apiRoutes.group("/position", (router) => {
  router.get("/", requireAuth, positionController.positionList);
  router.post("/", requireAuth, positionController.storePosition);
  router.put("/:id", requireAuth, positionController.modifyPosition);
  router.delete("/:id", requireAuth, positionController.destroyPosition);
});

apiRoutes.group("/access", (router) => {
  router.get(
    "/by-position/:id",
    requireAuth,
    accessController.accessByPosition
  );
  router.post("/", requireAuth, accessController.storeAccess);
  router.put(
    "/by-position/:id",
    requireAuth,
    accessController.modifyAccessByPosition
  );
});

apiRoutes.group("/audit-trail", (router) => {
  router.get("/", requireAuth, trailController.trailList);
  router.post("/", requireAuth, trailController.storeTrail);
});

apiRoutes.group("/municipality", (router) => {
  router.get("/", requireAuth, municipalityController.municipalityList);
});

apiRoutes.group("/patient", (router) => {
  router.get("/", requireAuth, patientController.patientListController);
});

apiRoutes.group("/consultation", (router) => {
  router.get(
    "/:ConsId",
    requireAuth,
    consultationController.consultationListController
  );
  router.post(
    "/",
    requireAuth,
    consultationController.storeConsultationController
  );
  router.put(
    "/:id",
    requireAuth,
    consultationController.modifyConsultationController
  );
  router.delete(
    "/:ConsID",
    requireAuth,
    consultationController.destroyConsultationController
  );
});

apiRoutes.group("/medicine", (router) => {
  router.get("/", requireAuth, medicineController.medicineList);
  router.post("/", requireAuth, medicineController.storeMedicine);
  router.put("/:id", requireAuth, medicineController.modifyMedicine);
  router.delete("/:id", requireAuth, medicineController.destroyMedicine);
});

apiRoutes.group("/dossage-form", (router) => {
  router.get("/", requireAuth, dossageController.dossageFormList);
  router.post("/", requireAuth, dossageController.storeDossageForm);
  router.put("/:id", requireAuth, dossageController.modifyDossageForm);
  router.delete("/:id", requireAuth, dossageController.destroyDossageForm);
});

apiRoutes.group("/uom", (router) => {
  router.get("/", requireAuth, uomController.uomListController);
  router.post("/", requireAuth, uomController.storeUomController);
  router.put("/:id", requireAuth, uomController.modifyUomController);
  router.delete("/:id", requireAuth, uomController.destroyUomController);
});

apiRoutes.group("/consultationreport", (router) => {
  router.get(
    "/",
    requireAuth,
    consultationreportController.consultationreportController
  );
  router.get(
    "/illness",
    requireAuth,
    consultationreportController.consultationillnessreportController
  );
  router.get(
    "/department",
    requireAuth,
    consultationreportController.consultationdepartmentreportController
  );
});

apiRoutes.group("/company", (router) => {
  router.get("/", requireAuth, companyController.companyList);
  router.post("/", requireAuth, companyController.storeCompany);
  router.put("/:id", requireAuth, companyController.modifyCompany);
  router.delete("/:id", requireAuth, companyController.destroyCompany);
});

apiRoutes.group("/department", (router) => {
  router.get("/", requireAuth, departmentController.departmentList);
  router.post("/", requireAuth, departmentController.storeDepartment);
  router.put("/:id", requireAuth, departmentController.modifyDepartment);
  router.delete("/:id", requireAuth, departmentController.destroyDepartment);
});

apiRoutes.group("/section", (router) => {
  router.get("/", requireAuth, sectionController.sectionList);
  router.get(
    "/filtered/:SNo",
    requireAuth,
    sectionController.FilteredsectionList
  );
  router.post("/", requireAuth, sectionController.storeSection);
  router.put("/:id", requireAuth, sectionController.modifySection);
  router.delete("/:id", requireAuth, sectionController.destroySection);
});

apiRoutes.group("/gender", (router) => {
  router.get("/", requireAuth, genderController.genderList);
  router.post("/", requireAuth, genderController.storeGender);
  router.put("/:id", requireAuth, genderController.modifyGender);
  router.delete("/:id", requireAuth, genderController.destroyGender);
});

apiRoutes.group("/civilstatus", (router) => {
  router.get("/", requireAuth, civilstatusController.CivilStatusListController);
  router.post(
    "/",
    requireAuth,
    civilstatusController.storeCivilStatusController
  );
  router.put(
    "/:id",
    requireAuth,
    civilstatusController.modifyCivilStatusController
  );
  router.delete(
    "/:id",
    requireAuth,
    civilstatusController.destroyCivilStatusController
  );
});

apiRoutes.group("/bloodtype", (router) => {
  router.get("/", requireAuth, bloodtypeController.BloodTypeListController);
  router.post("/", requireAuth, bloodtypeController.storeBloodTypeController);
  router.put(
    "/:id",
    requireAuth,
    bloodtypeController.modifyBloodTypeController
  );
  router.delete(
    "/:id",
    requireAuth,
    bloodtypeController.destroyBloodTypeController
  );
});

apiRoutes.group("/relation", (router) => {
  router.get("/", requireAuth, relationController.RelationListController);
  router.post("/", requireAuth, relationController.storeRelationController);
  router.put("/:id", requireAuth, relationController.modifyRelationController);
  router.delete(
    "/:id",
    requireAuth,
    relationController.destroyRelationController
  );
});

apiRoutes.group("/country", (router) => {
  router.get("/", requireAuth, countryController.countryList);
  router.post("/", requireAuth, countryController.storeCountry);
  router.put("/:id", requireAuth, countryController.modifyCountry);
  router.delete("/:id", requireAuth, countryController.destroyCountry);
  router.get(
    "/countryname/:name",
    requireAuth,
    countryController.countryDuplicateController
  );
});

apiRoutes.group("/region", (router) => {
  router.get("/", requireAuth, regionController.regionListController);
  router.get(
    "/filtered/:RNo",
    requireAuth,
    regionController.regionFilteredListController
  );
  router.post("/", requireAuth, regionController.storeRegionController);
  router.put("/:id", requireAuth, regionController.modifyRegionController);
  router.delete("/:id", requireAuth, regionController.destroyRegionController);
  router.get(
    "/regionname/:name",
    requireAuth,
    regionController.regionNameController
  );
});

apiRoutes.group("/province", (router) => {
  router.get("/", requireAuth, provinceController.provinceListController);
  router.get(
    "/filtered/:PNo",
    requireAuth,
    provinceController.provinceFilteredListController
  );
  router.post("/", requireAuth, provinceController.storeProvinceController);
  router.put("/:id", requireAuth, provinceController.modifyProvinceController);
  router.delete(
    "/:id",
    requireAuth,
    provinceController.destroyProvinceController
  );
  router.get(
    "/provincename/:name",
    requireAuth,
    provinceController.provinceNameController
  );
});

apiRoutes.group("/city", (router) => {
  router.get("/", requireAuth, cityController.cityListController);
  router.get(
    "/filtered/:CNo",
    requireAuth,
    cityController.cityFilteredListController
  );
  router.post("/", requireAuth, cityController.storeCityController);
  router.put("/:id", requireAuth, cityController.modifyCityController);
  router.delete("/:id", requireAuth, cityController.destroyCityController);
  router.get("/cityname/:name", requireAuth, cityController.cityNameController);
});

apiRoutes.group("/medicalrecord", (router) => {
  router.get(
    "/:MRID",
    requireAuth,
    medicalrecordController.medicalrecordController
  );
});

apiRoutes.group("/beneficiaries", (router) => {
  router.get(
    "/:PID",
    requireAuth,
    beneficiariesController.beneficiariesListController
  );
  router.post(
    "/",
    requireAuth,
    beneficiariesController.storeBeneficiariesController
  );
  router.put(
    "/:id",
    requireAuth,
    beneficiariesController.modifyBeneficiariesController
  );
  router.delete(
    "/:BID",
    requireAuth,
    beneficiariesController.destroyBeneficiariesController
  );
});

apiRoutes.group("/access", (router) => {
  router.get(
    "/by-position/:id",
    requireAuth,
    accessController.accessByPosition
  );
  router.post("/", requireAuth, accessController.storeAccess);
  router.put(
    "/by-position/:id",
    requireAuth,
    accessController.modifyAccessByPosition
  );
});

apiRoutes.group("/salesorder", (router) => {
  router.get(
    "/",
    requireAuth,
    salesorderController.EmployeeOrderListController
  );
});

apiRoutes.group("/medicineorder", (router) => {
  router.get(
    "/orderid",
    requireAuth,
    medicineorderController.OrderNumberController
  );
  router.get(
    "/",
    requireAuth,
    medicineorderController.AllMedicineOrderListController
  );
  router.get(
    "/:MorderId",
    requireAuth,
    medicineorderController.MedicineOrderListController
  );
  router.post(
    "/",
    requireAuth,
    medicineorderController.storeMedicineOrderController
  );
});

apiRoutes.group("/medicineapprover", (router) => {
  router.get(
    "/",
    requireAuth,
    medicineapproverController.MedicineApproverController
  );
  router.get(
    "/personels",
    requireAuth,
    medicineapproverController.AuthorizePersonelController
  );
  router.post(
    "/",
    requireAuth,
    medicineapproverController.storeMedicineApproverController
  );
  router.delete(
    "/:ID",
    requireAuth,
    medicineapproverController.destroyAuthorizePersonelController
  );
});

apiRoutes.group("/medicinerelease", (router) => {
  router.get(
    "/:UL",
    requireAuth,
    medicinereleaseController.MedicineReleaseController
  );
  router.get(
    "/userlevel/:AL",
    requireAuth,
    medicinereleaseController.UserLevelController
  );
  router.get(
    "/approval/:NorderID",
    requireAuth,
    medicinereleaseController.MedicineApprovalListController
  );
  router.put(
    "/approval/:id",
    requireAuth,
    medicinereleaseController.modifyApproval
  );
  router.put(
    "/release/:id",
    requireAuth,
    medicinereleaseController.modifyRelease
  );
  router.put(
    "/reject/:id",
    requireAuth,
    medicinereleaseController.modifyReject
  );
});

apiRoutes.group("/ape", (router) => {
  router.get("/", requireAuth, apeController.employeeListController);
  router.get("/records/:APEid", requireAuth, apeController.ApeListController);
  router.post(
    "/upload-apephoto",
    // requireAuth,
    ApeUpload.array("APEImage", 5),
    apeController.uploadApePhotoController
  );
});

apiRoutes.group("/sickness", (router) => {
  router.get("/", requireAuth, sicknessController.SicknessListController);
  router.post("/", requireAuth, sicknessController.storeSicknessController);
  router.put("/:id", requireAuth, sicknessController.modifySicknessController);
  router.delete(
    "/:id",
    requireAuth,
    sicknessController.destroySicknessController
  );
});

apiRoutes.group("/uom", (router) => {
  router.get("/", requireAuth, uomController.uomListController);
  router.post("/", requireAuth, uomController.storeUomController);
  router.put("/:id", requireAuth, uomController.modifyUomController);
  router.delete("/:id", requireAuth, uomController.destroyUomController);
});

apiRoutes.group("/medicinesalesreport", (router) => {
  router.get(
    "/",
    requireAuth,
    medicinesalesreportController.medicinesalesreportController
  );
  router.get(
    "/item",
    requireAuth,
    medicinesalesreportController.medicineitemlistController
  );
  router.get(
    "/type",
    requireAuth,
    medicinesalesreportController.medicinetypelistController
  );
});

apiRoutes.group("/laboratory", (router) => {
  router.get("/", requireAuth, laboratoryController.employeeListController);
  router.get(
    "/records/:LABid",
    requireAuth,
    laboratoryController.LaboratoryListController
  );
  router.post(
    "/upload-laboratoryphoto",
    // requireAuth,
    LaboratoryUpload.array("LaboratoryImage", 5),
    laboratoryController.uploadLaboratoryPhotoController
  );
});

apiRoutes.group("/clinicpatients", (router) => {
  router.get(
    "/",
    requireAuth,
    clinicpatientsController.ClinicPatientsListController
  );
  router.post(
    "/",
    requireAuth,
    clinicpatientsController.storeClinicPatientsController
  );
  router.put(
    "/:id",
    requireAuth,
    clinicpatientsController.modifyClinicPatientsController
  );
  router.delete(
    "/:id",
    requireAuth,
    clinicpatientsController.destroyClinicPatientsController
  );
});

export default apiRoutes;
