import expressGroup from 'express-group-routes';
import  express from 'express';

import apiRoutes from './api.routes.js';

export const apiRouter = express.Router();

apiRouter.group(router => {
    router.use(apiRoutes)
});
