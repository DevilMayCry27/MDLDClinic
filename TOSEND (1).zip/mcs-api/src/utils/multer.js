import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "node:fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const fullpath = path.join(__dirname, "..", "..", "public", "profiles");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, fullpath);
  },
  filename: function (req, file, cb) {
    let [filename, extension] = file.originalname.split(".");
    cb(null, req.body.FileName + "." + extension);
  },
});

export const upload = multer({ storage: storage });

export const forumUpload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      const forumPath = path.join(__dirname, "..", "..", "public", "forum");

      cb(null, forumPath);
    },
    filename: function (req, file, cb) {
      let [filename, extension] = file.originalname.split(".");

      cb(null, filename + "." + extension);
    },
  }),
});

export const ApeUpload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      const folderName = `./public/APE/${req.body.EmployeeId}`;
      try {
        if (!fs.existsSync(folderName)) {
          fs.mkdirSync(folderName);
        }
      } catch (err) {
        console.error(err);
      }

      cb(null, `./public/APE/${req.body.EmployeeId}`);
    },
    filename: async function (req, file, cb) {
      let [filename, extension] = file.originalname.split(".");
      console.log(filename, extension, "extension");
      cb(
       
        null,
        req.body.EmployeeId + "-" + filename.replace(/[^a-zA-Z0-9]/g, '') + ".pdf"
      );
    },
  }),
});

// export const ApeUpload = multer({
//   storage: multer.diskStorage({
//     destination: function (req, file, cb) {
//       const folderName = `./public/APE/${req.body.EmployeeId}`;
//       try {
//         if (!fs.existsSync(folderName)) {
//           fs.mkdirSync(folderName);
//         }
//       } catch (err) {
//         console.error(err);
//       }

//       cb(null, `./public/APE/${req.body.EmployeeId}`);
//     },
//     filename: async function (req, file, cb) {
//       let [filename, extension] = file.originalname.split(".");
//       cb(
//         null,
//         req.body.EmployeeId + "-" + filename.replace(/'/, "") + "." + extension
//       );
//     },
//   }),
// });

export const LaboratoryUpload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      const folderName = `./public/Laboratory/${req.body.EmployeeId}`;
      try {
        if (!fs.existsSync(folderName)) {
          fs.mkdirSync(folderName);
        }
      } catch (err) {
        console.error(err);
      }

      cb(null, `./public/Laboratory/${req.body.EmployeeId}`);
    },
    filename: async function (req, file, cb) {
      let [filename, extension] = file.originalname.split(".");
      console.log(filename, extension, "extension");
      cb(
       
        null,
        req.body.EmployeeId + "-" + filename.replace(/[^a-zA-Z0-9]/g, '') + ".pdf"
      );
    },
  }),
});

export const RemoveAssets = async (folder, fileList) => {
  // Ex. folder = 'forum', fileList = ['filename.jpg']

  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);

  const unlinkFile = async (filePath) => {
    return new Promise((resolve, reject) => {
      fs.unlink(filePath, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  };

  const getFilePath = (folder, file) => {
    return path.join(__dirname, "..", "..", "public", folder, file);
  };

  await Promise.all([
    fileList.map(async (file) => {
      const filePath = getFilePath(folder, file);

      try {
        await unlinkFile(filePath);
        console.log("File deleted successfully");
      } catch (error) {
        console.error("Error deleting file:", error);
      }
    }),
  ]);
};
