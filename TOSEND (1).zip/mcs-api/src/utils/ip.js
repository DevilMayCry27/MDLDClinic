export const getLocalIpAddress = (ip) => {
    return ip.replace('::ffff:', '').trim();
}