import nodemailer from 'nodemailer'

let transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER, 
      pass: process.env.EMAIL_PW, 
    },
    tls: {
      rejectUnauthorized:false
    }
});

export const sendemailNotificiation = async() => {

    await transporter.sendMail({
    from: '"LLI Medicine Release System" <jaalcantara@lloydlab.com>',
    to: 'jaalcantara@lloydlab.com, riocastro@lloydlab.com',
    subject: 'New Approval for Medicine Release',
    html: `<p>
            Good day!
            <br><br>
            We're awaiting new approval to release medicines. 
            <br><br>
            http://172.16.19.233:8083/U2FsdGVkX1/QLxqeylQ1EhJvXMqSR6wIboFzTJ0cusR5fRC5sBSDDgKrsFoA0x0Q
            <br><br>
            This email is system generated.<br>
        </p>`, 
  });

    
}
