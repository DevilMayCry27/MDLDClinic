export const getMysqlFormat = (date) =>
  date.toISOString().slice(0, 10) + " " + date.toLocaleTimeString("en-GB");

export const getCurrentYear = () => new Date().getFullYear();

export const getMnthIndx = () => new Date().getMonth() + 1;

export const getCurrentMonthName = () =>
  new Date().toLocaleString("default", { month: "long" });

export const convertToMinDigits = (value, digits) =>
  value.toLocaleString("en-US", {
    minimumIntegerDigits: digits,
    useGrouping: false,
  });

export const getUnixTime = () =>
  Math.round(
    new Date().getTime() / 1000 + Math.floor((1 + Math.random()) * 3333)
  );

export const addDays = (date, days) => {
  let temp = new Date(date);

  temp.setDate(temp.getDate() + days);
  return temp;
};

export const sundayCount = (fromDate, toDate) => {
  var from = new Date(fromDate);
  var to = new Date(toDate);

  var weekendDayCount = 0;

  while (from < to) {
    from.setDate(from.getDate() + 1);
    if (from.getDay() === 0) {
      ++weekendDayCount;
    }
  }

  return weekendDayCount;
};

export const makeUnique = (base) => {
  var now = new Date().getTime();
  var random = Math.floor(Math.random() * 100000);
  // zero pad random
  random = "-" + random;
  while (random.length < 5) {
    random = "0" + random;
  }
  return base + now + random;
};
