export const moduleType = {
  auth: 0,
  admin: 1,
  reference: 2,
  general: 3,
  report: 4,
};

export const app = {
  hris: 1,
  medical: 3,
};

export const modules = [
  {
    id: 33,
    module: "positions",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 34,
    module: "users",
    menu: moduleType.admin,
    app: app.medical,
  },
  {
    id: 40,
    module: "patients",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 41,
    module: "consultation",
    menu: moduleType.general,
    app: app.medical,
  },
  {
    id: 42,
    module: "medicines",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 43,
    module: "company",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 44,
    module: "departments",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 45,
    module: "section",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 46,
    module: "gender",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 47,
    module: "civilstatus",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 48,
    module: "bloodtype",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 49,
    module: "relationship",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 50,
    module: "country",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 51,
    module: "region",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 52,
    module: "province",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 53,
    module: "city",
    menu: moduleType.admin,
    app: app.hris,
  },
  {
    id: 54,
    module: "sales",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 55,
    module: "medicineapprover",
    menu: moduleType.admin,
    app: app.medical,
  },
  {
    id: 56,
    module: "medicinerelease",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 57,
    module: "ape",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 58,
    module: "sickness",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 59,
    module: "uom",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 60,
    module: "dosage",
    menu: moduleType.reference,
    app: app.medical,
  },
  {
    id: 61,
    module: "laboratory",
    menu: moduleType.reference,
    app: app.medical,
  },
];
