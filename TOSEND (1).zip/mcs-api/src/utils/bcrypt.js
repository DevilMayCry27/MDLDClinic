import bcrypt from 'bcrypt';

const saltRounds = 10;

export const encryptText = async (text) => {
    return await bcrypt.hash(text, saltRounds);
} 

export const comparetext = async (text,comparator) => {
    return await bcrypt.compare(text, comparator);
}