import jwt from "jsonwebtoken";

const tokenSecret = process.env.TOKEN_SECRET;

export const createToken = (id, maxAge = 1 * 24 * 60 * 60) => {
  return jwt.sign({ id }, tokenSecret, {
    expiresIn: maxAge,
  });
};

export const verifyToken = (token) => {
  return jwt.verify(token, tokenSecret, (err, decodedToken) => {
    if (err) {
      return false;
    }
    return decodedToken;
  });
};
