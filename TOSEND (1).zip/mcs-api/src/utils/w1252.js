import * as windows1252 from "windows-1252";

export const encryptDecrypt = (value) => {
  try {
    let encryptedText = "";
    const pwdArray = Object.assign([], value);

    pwdArray.forEach((element) => {
      const converted = windows1252.encode(element)[0];
      const toBeDecode = new Uint16Array([
        converted < 128 ? converted + 128 : converted - 128,
      ]);
      const decoded = windows1252.decode(toBeDecode);

      encryptedText += decoded;
    });

    return encryptedText;
  } catch (error) {
    console.log(error);
  }
};

export const isHashCodeMatch = (password, oldPassword) => {
  return password == encryptDecrypt(oldPassword);
};
