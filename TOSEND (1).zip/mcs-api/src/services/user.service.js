import { executeQuery } from "../db/connection.js";
import {
  getUserListQuery,
  getUserByUsernameQuery,
  postUserQuery,
  postUserProfileQuery,
  putUserQuery,
  putUserProfileQuery,
  deleteUserQuery,
  deleteUserProfileQuery,
} from "../db/queries.js";
import { encryptText } from "../utils/bcrypt.js";

export const getUserList = async () => {
  const query = getUserListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postUser = async (data) => {
  try {
    const {
      UserName,
      Password,
      Status,
      FirstName,
      MiddleName,
      LastName,
      DepartmentId,
      PositionId,
      SectionId,
    } = data;
    const hashPwd = await encryptText(Password);

    const userQuery = postUserQuery(UserName, hashPwd, Status);
    const user = await executeQuery(userQuery);

    const extUserQuery = getUserByUsernameQuery(UserName);
    const extUser = await executeQuery(extUserQuery);

    const userProfileQuery = postUserProfileQuery(
      extUser[0]?.ID,
      FirstName,
      MiddleName,
      LastName,
      DepartmentId,
      PositionId,
      SectionId,
      Status
    );
    const result = await executeQuery(userProfileQuery);

    return result;
  } catch (error) {
    console.log(error);
    if (error?.code === "ER_DUP_ENTRY") return { code: error?.code };
  }
};

export const putUser = async (data) => {
  try {
    const {
      UserId,
      Status,
      FirstName,
      MiddleName,
      LastName,
      DepartmentId,
      PositionId,
      SectionId,
    } = data;

    const userQuery = putUserQuery(Status, UserId);
    const user = await executeQuery(userQuery);

    const userProfileQuery = putUserProfileQuery(
      FirstName,
      MiddleName,
      LastName,
      DepartmentId,
      PositionId,
      SectionId,
      Status,
      UserId
    );
    const result = await executeQuery(userProfileQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteUser = async (status, user_id) => {
  try {
    const userProfileQuery = deleteUserProfileQuery(status, user_id);
    const result = await executeQuery(userProfileQuery);

    const userQuery = deleteUserQuery(user_id);
    const user = await executeQuery(userQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
