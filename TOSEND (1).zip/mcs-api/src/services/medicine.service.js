import { executeQuery } from "../db/connection.js";
import {
  getMedicineListQuery,
  postMedicineQuery,
  putMedicineQuery,
  deleteMedicineQuery,
} from "../db/queries.js";

export const getMedicineList = async () => {
  const query = getMedicineListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postMedicine = async (data) => {
  try {
    const { Code, GenericName, LabelClaim, UomID, UnitPrice } = data;

    const query = postMedicineQuery(
      Code,
      GenericName,
      LabelClaim,
      UomID,
      UnitPrice
    );
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putMedicine = async (data) => {
  try {
    const { MedicineId, Code, GenericName, LabelClaim, UomID, UnitPrice } =
      data;

    const query = putMedicineQuery(
      MedicineId,
      Code,
      GenericName,
      LabelClaim,
      UnitPrice,
      UomID
    );
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteMedicine = async (MedicineId) => {
  try {
    const query = deleteMedicineQuery(MedicineId);
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};
