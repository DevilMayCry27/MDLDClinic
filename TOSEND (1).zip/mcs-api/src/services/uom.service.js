import { executeQuery } from "../db/connection.js";
import {
  getUomListQuery,
  postUomQuery,
  putUomQuery,
  deleteUomQuery,
} from "../queries/uom.queries.js";

export const getUomListService = async () => {
  const query = getUomListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postUomService = async (data) => {
  try {
    const { Unit } = data;

    const query = postUomQuery(Unit);
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putUomService = async (data) => {
  try {
    const { Unit, Status, UomId } = data;

    const query = putUomQuery(Unit, Status, UomId);
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteUomService = async (UomId) => {
  try {
    const query = deleteUomQuery(UomId);
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};
