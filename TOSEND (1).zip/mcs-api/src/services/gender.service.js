import { executeQuery } from "../db/connection.js";
import {
  getGenderListQuery,
  postGenderQuery,
  putGenderQuery,
  deleteGenderQuery,
} from "../queries/gender.queries.js";

export const getGenderList = async () => {
  const query = getGenderListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postGender = async (data) => {
  try {
    const { Name, Status } = data;

    const genderQuery = postGenderQuery(Name, Status);
    const result = await executeQuery(genderQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putGender = async (data) => {
  try {
    const { GenderId, Name, Status } = data;

    const genderQuery = putGenderQuery(GenderId, Name, Status);
    const result = await executeQuery(genderQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteGender = async (GenderId) => {
  try {
    const genderQuery = deleteGenderQuery(GenderId);
    const result = await executeQuery(genderQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
