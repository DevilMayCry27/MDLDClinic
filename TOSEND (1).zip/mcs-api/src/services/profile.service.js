import { executeQuery } from "../db/connection.js";
import { getUserProfileQuery } from "../db/queries.js";
import {
  getCurrentUserInfoByUserIdQuery,
  getUserByIdQuery,
  updatePasswordQuery,
  updateProfileByCurrentUserQuery,
} from "../queries/profile.queries.js";

export const getUserProfile = async (user_id) => {
  const userProfileQuery = getUserProfileQuery(user_id);
  const result = await executeQuery(userProfileQuery);
  return result;
};

export const getUserById = async (userId) => {
  return await executeQuery(getUserByIdQuery(userId));
};

export const updatePassword = async (userId, username, hashPassword) => {
  return await executeQuery(
    updatePasswordQuery(userId, username, hashPassword)
  );
};

export const getCurrentUserInfoByUserId = async (userId) => {
  return await executeQuery(getCurrentUserInfoByUserIdQuery(userId));
};

export const updateProfileByCurrentUser = async (
  FirstName,
  MiddleName,
  LastName,
  ContactNo,
  StreetNo,
  Baranggay,
  MunicipalityID,
  ProvinceID,
  userID
) => {
  return await executeQuery(
    updateProfileByCurrentUserQuery(
      FirstName,
      MiddleName,
      LastName,
      ContactNo,
      StreetNo,
      Baranggay,
      MunicipalityID,
      ProvinceID,
      userID
    )
  );
};
