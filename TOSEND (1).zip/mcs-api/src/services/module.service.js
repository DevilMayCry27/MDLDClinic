import { executeQuery } from "../db/connection.js";
import {
  getModuleListQuery,
  postModuleQuery,
  isModuleExistQuery,
  isWebFeatureAccessExistQuery,
} from "../db/queries.js";
import { modules } from "../utils/constant.js";
import { getPositionList } from "../services/position.service.js";
import { postWebFeatureAccess } from "../services/access.service.js";

export const getModuleList = async () => {
  const query = getModuleListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postModule = async (data) => {
  try {
    const { ID, Feature, Menu, App } = data;

    const query = postModuleQuery(ID, Feature, Menu, App);
    const result = await executeQuery(query);

    const positions = await getPositionList();

    for (const position of positions) {
      await postWebFeatureAccess({
        UserTypeID: position?.ID,
        WebFeatureId: ID,
      });
    }

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const isModuleExist = async (module_id) => {
  const query = isModuleExistQuery(module_id);
  const result = await executeQuery(query);

  return result;
};

export const populateModule = async () => {
  try {

    for (const module of modules) {
      const isExist = await isModuleExist(module.id);

      if (!isExist?.length) {
        await postModule({
          ID: module.id,
          Feature: module.module,
          Menu: module.menu,
          App: module.app,
        });
      }
    }

    return { message: "module seeder populate success!" };
  } catch (error) {
    console.log(error);
  }
};

export const isModuleAccessExist = async (usertype, feature) => {
  try {
    const query = isWebFeatureAccessExistQuery(usertype, feature);
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const populateModuleAccess = async () => {
  const utypes = await getPositionList();

  for (let utype of utypes) {
    const wfs = await getModuleList();

    for (let wf of wfs) {
      const isExist = await isModuleAccessExist(utype?.ID, wf?.ID);

      if (!isExist?.length) {
        await postWebFeatureAccess({
          UserTypeID: utype?.ID,
          WebFeatureId: wf?.ID,
        });
      }
    }
  }
};
