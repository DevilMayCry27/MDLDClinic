import { executeQuery } from "../db/connection.js";
import {
  getCivilStatusListQuery,
  postCivilStatusQuery,
  putCivilStatusQuery,
  deleteCivilStatusQuery,
} from "../queries/civilstatus.queries.js";

export const getCivilStatusListService = async () => {
  const query = getCivilStatusListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postCivilStatusService = async (data) => {
  try {
    const { Name, Status } = data;

    const civilStatusQuery = postCivilStatusQuery(Name, Status);
    const result = await executeQuery(civilStatusQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putCivilStatusService = async (data) => {
  try {
    const { CivilStatusId, Name, Status } = data;

    const civilStatusQuery = putCivilStatusQuery(CivilStatusId, Name, Status);
    const result = await executeQuery(civilStatusQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteCivilStatusService = async (CivilStatusId) => {
  try {
    const civilStatusQuery = deleteCivilStatusQuery(CivilStatusId);
    const result = await executeQuery(civilStatusQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
