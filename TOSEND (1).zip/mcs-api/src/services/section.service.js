import { executeQuery } from "../db/connection.js";
import {
  getFilteredSectionListQuery,
  getSectionListQuery,
  postSectionQuery,
  putSectionQuery,
  deleteSectionQuery,
} from "../queries/departmentsection.queries.js";

export const getSectionList = async () => {
  const query = getSectionListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getFilteredSectionList = async (SNo) => {
  const query = getFilteredSectionListQuery(SNo);
  const result = await executeQuery(query);

  return result;
};

export const postSection = async (data) => {
  try {
    const { Name, DepartmentID, Status } = data;

    const sectionQuery = postSectionQuery(Name, DepartmentID, Status);
    const result = await executeQuery(sectionQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putSection = async (data) => {
  try {
    const { SectionId, Name, Status } = data;

    const sectionQuery = putSectionQuery(SectionId, Name, Status);
    const result = await executeQuery(sectionQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteSection = async (SectionId) => {
  try {
    const sectionQuery = deleteSectionQuery(SectionId);
    const result = await executeQuery(sectionQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
