import { executeQuery } from "../db/connection.js";
import {
  getFilteredProvinceListQuery,
  getProvinceListQuery,
  getProvinceByProvincenameQuery,
  postProvinceQuery,
  putProvinceQuery,
  deleteProvinceQuery,
} from "../queries/province.queries.js";

export const getProvinceListService = async () => {
  const query = getProvinceListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getFilteredProvinceListService = async (PNo) => {
  const query = getFilteredProvinceListQuery(PNo);
  const result = await executeQuery(query);

  return result;
};

export const getProvinceByProvincenameService = async (name) => {
  const query = getProvinceByProvincenameQuery(name);
  const result = await executeQuery(query);

  return result;
};

export const postProvinceService = async (data) => {
  try {
    const { RegionId, Name, Status } = data;

    const provinceQuery = postProvinceQuery(RegionId, Name, Status);
    const result = await executeQuery(provinceQuery);

    return result;
  } catch (error) {
    console.log(error);
    if (error?.code === "ER_DUP_ENTRY") return { code: error?.code };
  }
};

export const putProvinceService = async (data) => {
  try {
    console.log(data);
    const { CountryId, Status, Name, RegionId, ID } = data;

    const provinceQuery = putProvinceQuery(
      Name,
      Status,
      CountryId,
      RegionId,
      ID
    );
    const result = await executeQuery(provinceQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteProvinceService = async (province_id) => {
  try {
    const provinceQuery = deleteProvinceQuery(province_id);
    const province = await executeQuery(provinceQuery);

    return province;
  } catch (error) {
    console.log(error);
  }
};
