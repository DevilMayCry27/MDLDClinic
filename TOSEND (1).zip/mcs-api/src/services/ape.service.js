import { executeQuery } from "../db/connection.js";
import {
  getEmployeeListQuery,
  getApeRecordsQuery,
  postApeRecordQuery,
} from "../queries/ape.queries.js";

export const getEmployeeListService = async () => {
  const query = getEmployeeListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getApeRecordListService = async (APEid) => {
  const query = getApeRecordsQuery(APEid);
  const result = await executeQuery(query);

  return result;
};

export const postApeRecordService = async (data, files) => {
  try {
    const { EmployeeId } = data;

    for (let i in files) {
      let filepath = EmployeeId + "/" + files[i]?.filename;
      await insertRecord(
        files[i]?.filename,
        EmployeeId,
        filepath,
        files[i]?.originalname
      );
    }
  } catch (error) {
    console.log(error);
  }
};

export const insertRecord = async (filename, empid, filepath, originalname) => {
  try {
    const ApeQuery = postApeRecordQuery(
      filename,
      empid,
      filepath,
      originalname
    );
    const result = await executeQuery(ApeQuery);
    return result;
  } catch (error) {
    console.log(error);
  }
};
