import { executeQuery } from "../db/connection.js";
import {
  getMedicineReleaseQuery,
  getUserLevelQuery,
  getApprovalOrderListQuery,
  putApprovalQuery,
  putReleaseQuery,
  putRejectQuery,
} from "../queries/medicinerelease.queries.js";

export const getMedicineReleaseService = async (UL) => {
  const query = getMedicineReleaseQuery(UL);
  const result = await executeQuery(query);

  return result;
};

export const getUserLevelService = async (AL) => {
  const query = getUserLevelQuery(AL);
  const result = await executeQuery(query);

  return result;
};

export const getMedicineOrderListService = async (NorderID) => {
  const query = getApprovalOrderListQuery(NorderID);
  const result = await executeQuery(query);

  return result;
};

export const putApprovalService = async (data) => {
  try {
    const { OrderId } = data;

    const approvalQuery = putApprovalQuery(OrderId);
    const result = await executeQuery(approvalQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putReleaseService = async (data) => {
  try {
    const { OrderId } = data;

    const releaseQuery = putReleaseQuery(OrderId);
    const result = await executeQuery(releaseQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putRejectService = async (data) => {
  try {
    const { OrderId, Remarks } = data;

    const releaseQuery = putRejectQuery(OrderId, Remarks);
    const result = await executeQuery(releaseQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
