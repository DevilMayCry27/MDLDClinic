import { executeQuery } from "../db/connection.js";
import {
  getConsultationListQuery,
  postConsultationQuery,
  putConsultationQuery,
  deleteConsultationQuery,
} from "../queries/consultation.queries.js";

export const getConsultationListService = async (ConsId) => {
  const query = getConsultationListQuery(ConsId);
  const result = await executeQuery(query);
  return result;
};

export const postConsultationService = async (data) => {
  try {
    const {
      UserId,
      Illness,
      Bp,
      Temp,
      Rr,
      Pr,
      Diagnosis,
      Recommendation,
      Physician,
    } = data;

    const consQuery = postConsultationQuery(
      UserId,
      Illness,
      Bp,
      Temp,
      Rr,
      Pr,
      Diagnosis,
      Recommendation,
      Physician
    );
    const result = await executeQuery(consQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putConsultationService = async (data) => {
  try {
    const {
      ConsID,
      Illness,
      Bp,
      Temp,
      Rr,
      Pr,
      Diagnosis,
      Recommendation,
      Physician,
    } = data;

    const consQuery = putConsultationQuery(
      ConsID,
      Illness,
      Bp,
      Temp,
      Rr,
      Pr,
      Diagnosis,
      Recommendation,
      Physician
    );
    const result = await executeQuery(consQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteConsultationService = async (ConsId) => {
  try {
    const consQuery = deleteConsultationQuery(ConsId);
    const result = await executeQuery(consQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
