import { executeQuery } from "../db/connection.js";
import {
  getBeneficiariesListQuery,
  postBeneficiariesQuery,
  putBeneficiariesQuery,
  deleteBeneficiariesQuery,
} from "../queries/beneficiaries.queries.js";

export const getBeneficiariesListService = async (PID) => {
  const query = getBeneficiariesListQuery(PID);
  const result = await executeQuery(query);

  return result;
};

export const postBeneficiariesService = async (data) => {
  try {
    const {
      EmployeeId,
      FirstName,
      MiddleName,
      LastName,
      RelationshipId,
      CountryId,
      RegionId,
      ProvinceId,
      CityId,
      Baranggay,
      ContactNumber,
      Status,
    } = data;

    const beneficiariesQuery = postBeneficiariesQuery(
      EmployeeId,
      FirstName,
      MiddleName,
      LastName,
      RelationshipId,
      CountryId,
      RegionId,
      ProvinceId,
      CityId,
      Baranggay,
      ContactNumber,
      Status
    );
    const result = await executeQuery(beneficiariesQuery);

    return result;
  } catch (error) {
    console.log(error);
    if (error?.code === "ER_DUP_ENTRY") return { code: error?.code };
  }
};

export const putBeneficiariesService = async (data) => {
  try {
    const {
      EmployeeId,
      FirstName,
      MiddleName,
      LastName,
      RelationshipId,
      CountryId,
      RegionId,
      ProvinceId,
      CityId,
      Baranggay,
      ContactNumber,
      Status,
      ID,
    } = data;

    const BeneficiariesQuery = putBeneficiariesQuery(
      EmployeeId,
      FirstName,
      MiddleName,
      LastName,
      RelationshipId,
      CountryId,
      RegionId,
      ProvinceId,
      CityId,
      Baranggay,
      ContactNumber,
      Status,
      ID
    );
    const result = await executeQuery(BeneficiariesQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteBeneficiariesService = async (BID) => {
  try {
    const beneficiariesQuery = deleteBeneficiariesQuery(BID);
    const beneficiaries = await executeQuery(beneficiariesQuery);

    return beneficiaries;
  } catch (error) {
    console.log(error);
  }
};
