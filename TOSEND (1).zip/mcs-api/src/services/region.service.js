import { executeQuery } from "../db/connection.js";
import {
  getFilteredRegionListQuery,
  getRegionListQuery,
  getRegionByRegionnameQuery,
  postRegionQuery,
  putRegionQuery,
  deleteRegionQuery,
} from "../queries/region.queries.js";

export const getRegionListService = async () => {
  const query = getRegionListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getFilteredRegionListService = async (RNo) => {
  const query = getFilteredRegionListQuery(RNo);
  const result = await executeQuery(query);

  return result;
};

export const getRegionByRegionnameService = async (name) => {
  const query = getRegionByRegionnameQuery(name);
  const result = await executeQuery(query);

  return result;
};

export const postRegionService = async (data) => {
  try {
    const { CountryId, RegionName, Status } = data;

    const regionQuery = postRegionQuery(CountryId, RegionName, Status);
    const result = await executeQuery(regionQuery);

    return result;
  } catch (error) {
    console.log(error);
    if (error?.code === "ER_DUP_ENTRY") return { code: error?.code };
  }
};

export const putRegionService = async (data) => {
  try {
    console.log(data);
    const { CountryId, Status, RegionName, ID } = data;

    const regionQuery = putRegionQuery(RegionName, Status, CountryId, ID);
    const result = await executeQuery(regionQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteRegionService = async (region_id) => {
  try {
    const regionQuery = deleteRegionQuery(region_id);
    const region = await executeQuery(regionQuery);

    return region;
  } catch (error) {
    console.log(error);
  }
};
