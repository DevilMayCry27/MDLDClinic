import { executeQuery } from "../db/connection.js";
import {
  getRelationListQuery,
  postRelationQuery,
  putRelationQuery,
  deleteRelationQuery,
} from "../queries/relationship.queries.js";

export const getRelationListService = async () => {
  const query = getRelationListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postRelationService = async (data) => {
  try {
    const { Name, Status } = data;

    const relationQuery = postRelationQuery(Name, Status);
    const result = await executeQuery(relationQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putRelationService = async (data) => {
  try {
    const { RelationId, Name, Status } = data;

    const relationQuery = putRelationQuery(RelationId, Name, Status);
    const result = await executeQuery(relationQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteRelationService = async (RelationId) => {
  try {
    const relationQuery = deleteRelationQuery(RelationId);
    const result = await executeQuery(relationQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
