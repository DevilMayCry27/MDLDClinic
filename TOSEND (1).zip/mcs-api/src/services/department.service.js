import { executeQuery } from "../db/connection.js";
import {
  getDepartmentListQuery,
  postDepartmentQuery,
  putDepartmentQuery,
  deleteDepartmentQuery,
} from "../queries/department.queries.js";

export const getDepartmentList = async () => {
  const query = getDepartmentListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postDepartment = async (data) => {
  try {
    const { Name, Status } = data;

    const departmentQuery = postDepartmentQuery(Name, Status);
    const result = await executeQuery(departmentQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putDepartment = async (data) => {
  try {
    const { Name, DepartmentID, Status } = data;

    const departmentQuery = putDepartmentQuery(Name, DepartmentID, Status);
    const result = await executeQuery(departmentQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteDepartment = async (DepartmentId) => {
  try {
    const departmentQuery = deleteDepartmentQuery(DepartmentId);
    const result = await executeQuery(departmentQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
