import { executeQuery } from "../db/connection.js";
import {
  getEmployeeListQuery,
  getLaboratoriesRecordsQuery,
  postLabRecordQuery,
} from "../queries/laboratory.queries.js";

export const getEmployeeListService = async () => {
  const query = getEmployeeListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getLaboratoriesRecordsService = async (LABid) => {
  const query = getLaboratoriesRecordsQuery(LABid);
  const result = await executeQuery(query);

  return result;
};

export const postLabRecordService = async (data, files) => {
  try {
    const { EmployeeId } = data;

    for (let i in files) {
      let filepath = EmployeeId + "/" + files[i]?.filename;
      await insertRecord(
        files[i]?.filename,
        EmployeeId,
        filepath,
        files[i]?.originalname
      );
    }
  } catch (error) {
    console.log(error);
  }
};

export const insertRecord = async (filename, empid, filepath, originalname) => {
  try {
    const LabQuery = postLabRecordQuery(
      filename,
      empid,
      filepath,
      originalname
    );
    const result = await executeQuery(LabQuery);
    return result;
  } catch (error) {
    console.log(error);
  }
};
