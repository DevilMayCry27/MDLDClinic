import { executeQuery } from "../db/connection.js";
import {
  getBloodTypeListQuery,
  postBloodTypeQuery,
  putBloodTypeQuery,
  deleteBloodTypeQuery,
} from "../queries/bloodtype.queries.js";

export const getBloodTypeListService = async () => {
  const query = getBloodTypeListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postBloodTypeService = async (data) => {
  try {
    const { Name, Status } = data;

    const bloodTypeQuery = postBloodTypeQuery(Name, Status);
    const result = await executeQuery(bloodTypeQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putBloodTypeService = async (data) => {
  try {
    const { BloodTypeId, Name, Status } = data;

    const bloodTypeQuery = putBloodTypeQuery(BloodTypeId, Name, Status);
    const result = await executeQuery(bloodTypeQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteBloodTypeService = async (BloodTypeId) => {
  try {
    const bloodTypeQuery = deleteBloodTypeQuery(BloodTypeId);
    const result = await executeQuery(bloodTypeQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
