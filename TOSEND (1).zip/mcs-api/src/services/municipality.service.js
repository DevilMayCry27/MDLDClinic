import { executeQuery } from "../db/connection.js";
import { getMunicipalityListQuery } from "../queries/municipality.queries.js";

export const getMunicipalityList = async () => {
  const result = await executeQuery(getMunicipalityListQuery());
  return result;
};
