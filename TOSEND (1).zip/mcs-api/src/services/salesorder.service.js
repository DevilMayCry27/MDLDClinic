import { executeQuery } from "../db/connection.js";
import { getEmployeeOrderListQuery } from "../queries/salesorder.queries.js";

export const getEmployeeOrderListService = async () => {
  const query = getEmployeeOrderListQuery();
  const result = await executeQuery(query);

  return result;
};
