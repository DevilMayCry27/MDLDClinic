import { executeQuery } from '../db/connection.js';
import { 
    getTrailLogsQuery,
    postTrailLogsQuery,
} from '../db/queries.js';

export const getTrailLogList = async() => {

    const query = getTrailLogsQuery();
    const result = await executeQuery(query);

    return result
}

export const postTrailLog = async(data) => {

    try {
        const { module, action, status, ip_address } = data;
        
        const query = postTrailLogsQuery(module,action,status,ip_address);
        const result = await executeQuery(query);

        return result;

    } catch (error) {
        console.log(error);
    }
}