import { executeQuery } from "../db/connection.js";
import {
  getPositionListQuery,
  getPositionByNameQuery,
  postPositionQuery,
  putPositionQuery,
  deletePositionQuery,
} from "../db/queries.js";
import { getModuleList } from "../services/module.service.js";
import { postWebFeatureAccess } from "../services/access.service.js";

export const getPositionList = async () => {
  const query = getPositionListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postPosition = async (data) => {
  try {
    const { PositionName } = data;

    const positionQuery = postPositionQuery(PositionName);
    await executeQuery(positionQuery);

    const posQuery = getPositionByNameQuery(PositionName);
    const result = await executeQuery(posQuery);

    const modules = await getModuleList();

    for (const module of modules) {
      await postWebFeatureAccess({
        UserTypeID: result[0]?.ID,
        WebFeatureId: module?.ID,
      });
    }

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putPosition = async (data) => {
  try {
    const { PositionId, PositionName } = data;

    const positionQuery = putPositionQuery(PositionId, PositionName);
    const result = await executeQuery(positionQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deletePosition = async (PositionId) => {
  try {
    const positionQuery = deletePositionQuery(PositionId);
    const result = await executeQuery(positionQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
