import { executeQuery } from "../db/connection.js";
import {
  getConsultationReportListQuery,
  getConsultationReportIllnessQuery,
  getDepartmentReportIllnessQuery,
} from "../queries/consultationreport.queries.js";

export const getConsultationReportListService = async () => {
  const query = getConsultationReportListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getConsultationReportIllnessService = async () => {
  const query = getConsultationReportIllnessQuery();
  const result = await executeQuery(query);

  return result;
};

export const getDepartmentReportIllnessService = async () => {
  const query = getDepartmentReportIllnessQuery();
  const result = await executeQuery(query);

  return result;
};
