import { executeQuery } from "../db/connection.js";
import {
  getWebFeatureAccessByPositionQuery,
  postWebFeatureAccessQuery,
  putWebFeatureAccessQuery,
} from "../db/queries.js";

export const getWebFeatureAccessByPosition = async (PositionId) => {
  const query = getWebFeatureAccessByPositionQuery(PositionId);
  const result = await executeQuery(query);

  return result;
};

export const postWebFeatureAccess = async (data) => {
  try {
    const { UserTypeID, WebFeatureId } = data;

    const query = postWebFeatureAccessQuery(UserTypeID, WebFeatureId);
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putWebFeatureAccess = async (data) => {
  try {
    const { Store, Retrieve, Modify, Destroy, Report, ID } = data;

    const query = putWebFeatureAccessQuery(
      Store,
      Retrieve,
      Modify,
      Destroy,
      Report,
      ID
    );
    const result = await executeQuery(query);

    return result;
  } catch (error) {
    console.log(error);
  }
};
