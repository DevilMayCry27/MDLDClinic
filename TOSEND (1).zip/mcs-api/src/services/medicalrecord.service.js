import { executeQuery } from "../db/connection.js";
import { getMedicalRecordListQuery } from "../queries/medicalrecord.queries.js";

export const getMedicalRecordListService = async (MRID) => {
  const query = getMedicalRecordListQuery(MRID);
  const result = await executeQuery(query);

  return result;
};
