import { db, executeQuery } from "../db/connection.js";
import { authenticate } from "../db/queries.js";
import { createToken } from "../utils/jwt.js";
import { encryptDecrypt } from "../utils/w1252.js";

export const authorized = async (data) => {
  try {
    const { username, password } = data;

    const encryptedPassword = encryptDecrypt(password);

    const query = authenticate(username, encryptedPassword);
    const result = await executeQuery(query);

    // return empty object if result is empty array
    if (!result.length) {
      return {
        message: "Invalid credentials",
      };
    }

    const token = createToken(result[0]["ID"]);
    return {
      token: token,
      user: {
        id: result[0]?.ID,
        name: `${result[0]?.FirstName} ${result[0]?.LastName}`,
        position: result[0]?.PositionName,
      },
    };
  } catch (error) {
    console.log(error);
  }
};
