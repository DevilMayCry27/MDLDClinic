import { executeQuery } from "../db/connection.js";
import {
  getApproverQuery,
  getAuthorizePersonelQuery,
  postMedicineApproverQuery,
  deleteAuthorizePersonelQuery,
} from "../queries/medicineapprover.queries.js";

export const getMedicineApproverService = async () => {
  const query = getApproverQuery();
  const result = await executeQuery(query);

  return result;
};

export const getAuthorizePersonelService = async () => {
  const query = getAuthorizePersonelQuery();
  const result = await executeQuery(query);

  return result;
};

export const postMedicineApproverService = async (data) => {
  try {
    const { EmployeeId, UserId, FirstName, MiddleName, LastName, Level } = data;

    const medicineOrderQuery = postMedicineApproverQuery(
      EmployeeId,
      UserId,
      FirstName,
      MiddleName,
      LastName,
      Level
    );
    const result = await executeQuery(medicineOrderQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteAuthorizePersonelService = async (ID) => {
  try {
    const authorizepersonelQuery = deleteAuthorizePersonelQuery(ID);
    const result = await executeQuery(authorizepersonelQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
