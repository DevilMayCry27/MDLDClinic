import { executeQuery } from '../db/connection.js';
import { 
    getDossageFormListQuery,
    postDossageFormQuery,
    putDossageFormQuery,
    deleteDossageFormQuery,
} from '../db/queries.js';

export const getDossageFormList = async() => {

    const query = getDossageFormListQuery();
    const result = await executeQuery(query);

    return result
}

export const postDossageForm = async(data) => {

    try {
        const { Form } = data;

        const query = postDossageFormQuery(Form);
        const result = await executeQuery(query);

        return result;

    } catch (error) {
        console.log(error);
    }
}

export const putDossageForm = async(data) => {

    try {
        const { DossageFormId, Form } = data;

        const query = putDossageFormQuery(DossageFormId,Form);
        const result = await executeQuery(query);

        return result;

    } catch (error) {
        console.log(error);
    }
}

export const deleteDossageForm = async(DossageFormId) => {

    try {
        const query = deleteDossageFormQuery(DossageFormId);
        const result = await executeQuery(query);

        return result;

    } catch (error) {
        console.log(error);
    }
}