import { executeQuery } from "../db/connection.js";
import {
  getCompanyListQuery,
  postCompanyQuery,
  putCompanyQuery,
  deleteCompanyQuery,
} from "../queries/company.queries.js";

export const getCompanyList = async () => {
  const query = getCompanyListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postCompany = async (data) => {
  try {
    const { CompanyName, CompanyDesc, Status } = data;

    const companyQuery = postCompanyQuery(CompanyName, CompanyDesc, Status);
    const result = await executeQuery(companyQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putCompany = async (data) => {
  try {
    const { CompanyId, CompanyName, CompanyDesc, Status } = data;

    const companyQuery = putCompanyQuery(
      CompanyId,
      CompanyName,
      CompanyDesc,
      Status
    );
    const result = await executeQuery(companyQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteCompany = async (CompanyId) => {
  try {
    const companyQuery = deleteCompanyQuery(CompanyId);
    const result = await executeQuery(companyQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
