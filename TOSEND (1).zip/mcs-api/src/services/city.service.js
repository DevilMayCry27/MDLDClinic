import { executeQuery } from "../db/connection.js";
import {
  getFilteredCityListQuery,
  getCityListQuery,
  getCityByCitynameQuery,
  postCityQuery,
  putCityQuery,
  deleteCityQuery,
} from "../queries/city.querires.js";

export const getCityListService = async () => {
  const query = getCityListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getFilteredCityListService = async (CNo) => {
  const query = getFilteredCityListQuery(CNo);
  const result = await executeQuery(query);

  return result;
};

export const getCityByCitynameService = async (name) => {
  const query = getCityByCitynameQuery(name);
  const result = await executeQuery(query);

  return result;
};

export const postCityService = async (data) => {
  try {
    const { ProvinceId, CityName, Status } = data;

    const cityQuery = postCityQuery(ProvinceId, CityName, Status);
    const result = await executeQuery(cityQuery);

    return result;
  } catch (error) {
    console.log(error);
    if (error?.code === "ER_DUP_ENTRY") return { code: error?.code };
  }
};

export const putCityService = async (data) => {
  try {
    const { Status, CityName, ProvinceId, ID } = data;

    const cityQuery = putCityQuery(CityName, Status, ProvinceId, ID);
    const result = await executeQuery(cityQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteCityService = async (city_id) => {
  try {
    const cityQuery = deleteCityQuery(city_id);
    const city = await executeQuery(cityQuery);

    return city;
  } catch (error) {
    console.log(error);
  }
};
