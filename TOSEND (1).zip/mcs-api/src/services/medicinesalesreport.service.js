import { executeQuery } from "../db/connection.js";
import {
  getMedicineSalesReportListQuery,
  getMedicineItemListQuery,
  getMedicineTypeListQuery,
} from "../queries/medicinesalesreport.js";

export const getMedicineSalesReportListService = async () => {
  const query = getMedicineSalesReportListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getMedicineItemListService = async () => {
  const query = getMedicineItemListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getMedicineTypeListService = async () => {
  const query = getMedicineTypeListQuery();
  const result = await executeQuery(query);

  return result;
};
