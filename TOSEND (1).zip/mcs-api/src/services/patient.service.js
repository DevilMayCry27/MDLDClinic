import { executeQuery } from "../db/connection.js";
import { getPatientListQuery } from "../queries/patient.queries.js";

export const getPatientListService = async () => {
  const query = getPatientListQuery();
  const result = await executeQuery(query);

  return result;
};
