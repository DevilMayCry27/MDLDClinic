import { executeQuery } from "../db/connection.js";
import {
  getCountryListQuery,
  getCountryByCountrynameQuery,
  postCountryQuery,
  putCountryQuery,
  putRegion2Query,
  putProvince2Query,
  putCity2Query,
  deleteCountryQuery,
  deleteRegion2Query,
  deleteProvince2Query,
  deleteCity2Query,
} from "../queries/country.queries.js";

export const getCountryList = async () => {
  const query = getCountryListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getCountryDuplicateService = async (name) => {
  const query = getCountryByCountrynameQuery(name);
  const result = await executeQuery(query);

  return result;
};

export const postCountry = async (data) => {
  try {
    const { CountryName, Status } = data;

    const countryQuery = postCountryQuery(CountryName, Status);
    const result = await executeQuery(countryQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putCountry = async (data) => {
  try {
    const { CountryId, RegionId, CountryName, Status } = data;

    const countryQuery = putCountryQuery(CountryId, CountryName, Status);
    const result = await executeQuery(countryQuery);

    const regionQuery = putRegion2Query(Status, CountryId);
    const result2 = await executeQuery(regionQuery);

    const provinceQuery = putProvince2Query(Status, CountryId, RegionId);
    const result3 = await executeQuery(provinceQuery);

    const cityQuery = putCity2Query(Status, CountryId, RegionId);
    const result4 = await executeQuery(cityQuery);

    return result, result2, result3, result4;
  } catch (error) {
    console.log(error);
  }
};

export const deleteCountry = async (CountryId) => {
  try {
    const countryQuery = deleteCountryQuery(CountryId);
    const regionQuery = deleteRegion2Query(CountryId);
    const provinceQuery = deleteProvince2Query(CountryId);
    const cityQuery = deleteCity2Query(CountryId);

    const result = await executeQuery(countryQuery);
    const result2Query = await executeQuery(regionQuery);
    const result3Query = await executeQuery(provinceQuery);
    const result4Query = await executeQuery(cityQuery);

    return result, result2Query, result3Query, result4Query;
  } catch (error) {
    console.log(error);
  }
};
