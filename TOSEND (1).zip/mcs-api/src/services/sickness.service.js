import { executeQuery } from "../db/connection.js";
import {
  getSicknessListQuery,
  postSicknessQuery,
  putSicknessQuery,
  deleteSicknessQuery,
} from "../queries/sickness.queries.js";

export const getSicknessService = async () => {
  const query = getSicknessListQuery();
  const result = await executeQuery(query);

  return result;
};

export const postSicknessService = async (data) => {
  try {
    const { Illness } = data;

    const sicknessQuery = postSicknessQuery(Illness);
    const result = await executeQuery(sicknessQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const putSicknessService = async (data) => {
  try {
    const { Illness, SickID } = data;

    const sicknessQuery = putSicknessQuery(Illness, SickID);
    const result = await executeQuery(sicknessQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteSicknessService = async (SickID) => {
  try {
    const sicknessQuery = deleteSicknessQuery(SickID);
    const result = await executeQuery(sicknessQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};
