import { executeQuery } from "../db/connection.js";
import {
  isUsernameExistQuery,
  getClinicPatientListQuery,
  postClinicPatientQuery,
  postClinicPatientPassQuery,
  putClinicPatientsQuery,
  deleteClinicPatientsQuery,
} from "../queries/clinicpatients.queries.js";

export const getClinicPatientListService = async (CPID) => {
  const query = getClinicPatientListQuery(CPID);
  const result = await executeQuery(query);

  return result;
};

export const isUsernameExist = async (userName) => {
  try {
    const query = isUsernameExistQuery(userName);
    const result = await executeQuery(query);

    return result.length > 0;
  } catch (error) {
    throw new Error("Error checking username existence: " + error.message);
  }
};

export const generateUserNameFromData = async (
  firstName,
  middleName,
  lastName
) => {
  let un = `${firstName?.charAt(0)}${middleName?.charAt(0)}${lastName}`
    ?.toLowerCase()
    ?.replaceAll(" ", "")
    ?.replaceAll(".", "");

  const isExist = await isUsernameExist(un);

  if (isExist?.length) {
    un = await generateUniqueUserName(un);
  }

  return un;
};

export const postClinicPatientPassService = async (data) => {
  try {
    const { EmployeeCode, UserLevel, UserName, Password, Status } = data;

    const ClinicPatientPassQuery = postClinicPatientPassQuery(
      EmployeeCode,
      UserLevel,
      UserName,
      Password,
      Status
    );
    const result = await executeQuery(ClinicPatientPassQuery);

    return result;
  } catch (error) {
    console.log(error);
    if (error?.code === "ER_DUP_ENTRY") return { code: error?.code };
  }
};

export const postClinicPatientService = async (data) => {
  try {
    const {
      EmployeeCode,
      FirstName,
      MiddleName,
      LastName,
      GenderID,
      CountryID,
      RegionID,
      ProvinceID,
      MunicipalityID,
      Street,
      CivilStatusID,
      BloodTypeID,
      ContactNumber,
      HealthCareNo,
      SSSNo,
      PhNo,
      TINNo,
      PagibigNo,
      Email,
      DepartmentID,
      DepartmentSection,
      Status,
    } = data;

    const userName = await generateUserNameFromData(
      FirstName,
      MiddleName,
      LastName
    );

    await postClinicPatientPassService({
      EmployeeCode: EmployeeCode,
      UserLevel: "7",
      UserName: userName,
      Password: "±²³´",
      Status: "1",
    });

    const ClinicPatientQuery = postClinicPatientQuery(
      EmployeeCode,
      FirstName,
      MiddleName,
      LastName,
      GenderID,
      CountryID,
      RegionID,
      ProvinceID,
      MunicipalityID,
      Street,
      CivilStatusID,
      BloodTypeID,
      ContactNumber,
      HealthCareNo,
      SSSNo,
      PhNo,
      TINNo,
      PagibigNo,
      Email,
      DepartmentID,
      DepartmentSection,
      Status
    );
    const result = await executeQuery(ClinicPatientQuery);

    return result;
  } catch (error) {
    console.log(error);
    if (error?.code === "ER_DUP_ENTRY") return { code: error?.code };
  }
};

export const putClinicPatientService = async (data) => {
  try {
    const {
      EmployeeCode,
      FirstName,
      MiddleName,
      LastName,
      GenderID,
      CountryID,
      RegionID,
      ProvinceID,
      MunicipalityID,
      Street,
      CivilStatusID,
      BloodTypeID,
      ContactNumber,
      HealthCareNo,
      SSSNo,
      PhNo,
      TINNo,
      PagibigNo,
      Email,
      DepartmentID,
      DepartmentSection,
      Status,
      ID,
    } = data;

    const ClinicPatientQuery = putClinicPatientsQuery(
      EmployeeCode,
      FirstName,
      MiddleName,
      LastName,
      GenderID,
      CountryID,
      RegionID,
      ProvinceID,
      MunicipalityID,
      Street,
      CivilStatusID,
      BloodTypeID,
      ContactNumber,
      HealthCareNo,
      SSSNo,
      PhNo,
      TINNo,
      PagibigNo,
      Email,
      DepartmentID,
      DepartmentSection,
      Status,
      ID
    );
    const result = await executeQuery(ClinicPatientQuery);

    return result;
  } catch (error) {
    console.log(error);
  }
};

export const deleteClinicPatientService = async (id) => {
  try {
    const ClinicPatientQuery = deleteClinicPatientsQuery(id);
    const ClinicPatient = await executeQuery(ClinicPatientQuery);

    return ClinicPatient;
  } catch (error) {
    console.log(error);
  }
};
