import { executeQuery } from "../db/connection.js";
import {
  getOrderNumberQuery,
  getAllMedicineOrderListQuery,
  getMedicineOrderListQuery,
  postMedicineOrderQuery,
} from "../queries/medicineorders.queries.js";
import { sendemailNotificiation } from "../utils/sendEmail.js";

export const getOrderNumberService = async () => {
  const query = getOrderNumberQuery();
  const result = await executeQuery(query);

  return result;
};

export const getAllMedicineOrderListService = async () => {
  const query = getAllMedicineOrderListQuery();
  const result = await executeQuery(query);

  return result;
};

export const getMedicineOrderListService = async (MorderId) => {
  const query = getMedicineOrderListQuery(MorderId);
  const result = await executeQuery(query);

  return result;
};

export const postMedicineOrderListService = async (data) => {
  try {
    const { EmployeeId, NextOrderID, Type, Qty, GenericName, Price, Amount } =
      data;

    const medicineOrderQuery = postMedicineOrderQuery(
      EmployeeId,
      NextOrderID,
      Type,
      Qty,
      GenericName,
      Price,
      Amount
    );
    const result = await executeQuery(medicineOrderQuery);
    const email = await sendemailNotificiation();

    return result, email;
  } catch (error) {
    console.log(error);
  }
};
