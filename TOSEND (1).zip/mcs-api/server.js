import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import requestIp from "request-ip";
import dbConnect from "./src/db/connection.js";
import { apiRouter } from "./src/routes/index.js";
import { app, server } from "./src/socket/socket.js";

dotenv.config();

const PORT = process.env.PORT || 5000;
// const app = express();

//INITIAL CONFIGURATIONS
app.use(requestIp.mw());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

//DATABASE CONNECTION
dbConnect
  .then(() =>
    server.listen(PORT, () => console.log(`Server Running On Port: ${PORT}`))
  )
  .catch((error) => console.log(error.message));

//API ROUTES
app.get("/tesuto", async (req, res) => {
  res.send("HR Centralized Portal API");
});

app.use("/api", apiRouter);
